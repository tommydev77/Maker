<?php
ob_start();
//    ___________________________________///
//      ÷÷÷÷÷÷÷ FAST CODER ÷÷÷÷÷÷÷÷  ///
//      ÷÷÷÷÷÷÷÷ PHP TEAM ÷÷÷÷÷÷÷÷  ///
//      ÷÷÷÷÷÷÷ @Fast_Coder ÷÷÷÷÷÷÷  ///
//               ÷÷÷ @Webuzboy ÷÷÷           ///
//    __________________________________///
define('API_KEY','API_TOKEN');
$admin = "ADMIN_ID"; 

function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
function put($fayl,$nima){  
file_put_contents("$fayl","$nima");  
}  
function get($fayl){  
$get = file_get_contents("$fayl");  
return $get;  
}  
   function ty($chat_id){ 
   return bot('sendChatAction', [
   'chat_id' => $chat_id,
   'action' => 'typing',
   ]);
   } 
   function del($nomi){
   array_map('unlink', glob("$nomi"));
   }
          $replyc= json_encode([
           'resize_keyboard'=>false,
                'force_reply' => true,
                'selective' => true
            ]);
$efede = json_decode(file_get_contents('php://input'), true);

$update = json_decode(file_get_contents('php://input'));
$edname = $editm ->from->first_name;
$message = $update->message;
$mesid = $message->message_id;
$mid = $message->message_id;
$chat_id = $message->chat->id;
$forward = $update->message->forward_from;
$editm = $update->edited_message;
$fadmin = $message->from->id;
$tx = $message->text;

//callback
$data = $update->callback_query->data;
$qid = $update->callback_query->id;
$callcid = $update->callback_query->message->chat->id;
$clid = $update->callback_query->from->id;
$callmid = $update->callback_query->message->message_id;
$gid = $update->callback_query->message->chat->id;
$cid = $message->chat->id;
//call_back
$data = $update->callback_query->data;
$qid = $update->callback_query->id;
$callcid = $update->callback_query->message->chat->id;
$calltext = $update->callback_query->message->text;
$clid = $update->callback_query->from->id;
$callmid = $update->callback_query->message->message_id;
$gid = $update->callback_query->message->chat->id;

//user
$name = $message->from->first_name;

$id = $message->reply_to_message->from->id;   
$repmid = $message->reply_to_message->message_id; 
$repname = $message->reply_to_message->from->first_name;
$repulogin = $message->reply_to_message->from->username;
$reply = $message->reply_to_message;
$sreply = $message->reply_to_message->text;
$soat = date('H:i', strtotime('3 hour'));
$sana = date('d-M Y',strtotime('3 hour'));

$mid = $message->message_id;
$edname = $editm ->from->first_name;
$forward2 = $update->message->forward_from;
$editm = $update->edited_message;
mkdir("data");
mkdir("data/$fadmin");


$key1 = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"📸Photo Bo'lim"],
['text'=>"🗃Foydali Bo'lim"],],
[['text'=>"🌸Ramazon Taqvimi"],
['text'=>"📖Quron Haqida"],],
[['text'=>"🤲Ro'za Duosi"],
['text'=>"🏮Kanallarimiz"],],
[['text'=>"👨‍💻Bot ixtrochi"],
['text'=>"😏Rasm Yoqmadi"],],
[['text'=>"🏞Ism Zakas Gruppa✍"]]]
]);

$key2 = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"1️⃣STIL"],
['text'=>"2️⃣STIL"],],
[['text'=>"3️⃣STIL"],
['text'=>"4️⃣STIL"],],
[['text'=>"5️⃣STIL"],
['text'=>"6️⃣STIL"],],
[['text'=>"7️⃣STIL"],
['text'=>"8️⃣STIL"],],
[['text'=>"9️⃣STIL"],
['text'=>"🔟STIL"],],
[['text'=>"🔙Orqaga"]]]
]);

$key3 = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"1️⃣ STIL"],['text'=>"2️⃣ STIL"],],
[['text'=>"3️⃣ STIL"],
['text'=>"🔙Orqaga"]]]
]);

$key4 = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"1️⃣  STIL"],
['text'=>"2️⃣  STIL"],],
[['text'=>"🔙Orqaga"]]]
]);

$admkey = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"📊Statistika"],
['text'=>"🗂Bot Code"],],
[['text'=>"📄Xabar Jo'natish"],
['text'=>"🔙Orqaga"]]]
]);

$rkey = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"😇Ramazon Rasm"],['text'=>"🦠Karonavirus Rasm"],],
[['text'=>"🍃Juma Rasm"],
['text'=>"🔙Orqaga"]]]
]);

$fkey = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"🎅Yangi Yil"],
['text'=>"📰Yangiliklar"],],
[['text'=>"📊Statistika"],
['text'=>"🔙Orqaga"]]]
]);


if($tx == "/start" || $tx == "start"){
     bot('sendMessage',[
     'chat_id'=>$cid,
     'text'=>"
😁Assalomu Aleykum

🌸Bu Botdan Bir Qancha
😎Juda Ajoyib Bo'lgan
🍃Imkoniyatlarga Ega Bo'lasiz

◾Marxamat Pastdagi Menyulardan
⚠️O'zingizga Kerakligini Bosing",
     'reply_markup'=> $key1,
     ]);
}


if($tx=="📸Photo Bo'lim"){
    bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"
🔔Assalomu Aleykum😇
 
🔳Rasm Yasash Bo'limiga
🍃Xush Kelibsiz Do'stm
",
'parse_mode'=>'markdown',
'reply_markup'=> $rkey,
     ]);
}


if($tx=="🗃Foydali Bo'lim"){
    bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"
Assalomu Aleykum
 
📈Foydali Bo'limga
🍃Xush Kelibsiz Do'stm
",
'parse_mode'=>'markdown',
'reply_markup'=> $fkey,
     ]);
}

if($tx=="😏Rasm Yoqmadi"){
    bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"
😇Assalomu Aleykum

🤔Rasm Sizga Yoqmadimi
🤨Ismingiz Chekkaga Chiqib Qoldimi
🍃Agar Shunaqa Bo'lgan Bo'lsa
💡Adminga Murojat Qiling
✍Admin Sizga Cho'tki 
🏞Rasm Yasaberadi

⚠️Eslatma:Adminni Kichkina Sharti Bor
",'reply_markup'=>json_encode(
['inline_keyboard' => [
[['text'=>'👨‍🎓Adminga yozish','url'=>'http://t.me/$adminuser']],
 ]
]),
]);
}

if($tx=="👨‍💻Bot ixtrochi"){
    bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"
😇Assalomu Aleykum

👨‍💻Bot ixtrochi: [@$aminuser]

🧨Sizgaham Shunaqa😇 Va Boshqa
Turdagi Botlar Kerak Bo'lsa🦠
👨‍💻Bot ixtrochiga Murojat Qiling
",'reply_markup'=>json_encode(
['inline_keyboard' => [
[['text'=>'👨‍💻Bot Yasattirish','url'=>'http://t.me/$aminuser']],
 ]
]),
]);
}

if($tx=="🏞Ism Zakas Gruppa✍"){
    bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"
😇Hayrli Kun Do'stm😉

🏞Ism Zakas Gruppamizga ➕Qo'shil

➡️@Hazars_City⬅️

⚠️Kirib 50 Odam Qo'shsangiz 
🔰Sizga Rasm Yasab Beriladi

"
]);
}

if($tx=="🌸Ramazon Taqvimi"){
    bot('sendPhoto',[
        'chat_id'=>$chat_id,
'photo'=>"https://t.me/Hazars_City/8579",
'caption'=>"
Ramazon Taqvimi

",
]);
}


if($tx=="📖Quron Haqida"){
    bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"
📖Quron haqida
➖➖➖➖➖➖➖➖➖➖➖➖
Qurʼon (arab. القرآن oʻqimoq, qiroat qilmoq) — musulmonlarning asosiy muqaddas kitobi. Islom eʼtiqodiga koʻra,
Qurʼon vahiy orqali Muhammad paygʻambarga 610—632 yillar davomida nozil qilingan Allohning kalomi (Kalomulloh). Qurʼon „Kitob“ (yozuv), 
„Furqon“ (haq bilan botilning orasini ayiruvchi), 
„Zikr“ (eslatma), „Tanzil“ (nozil qilingan) kabi nomlar bilan atalib, „Nur“ (yorugʻlik), 
„Hudo“ (hidoyat), „Muborak“ (barakotli),
 „Mubin“ (ochiq-ravshan), „Bushro“ (xushxabar), 
„Aziz“ (eʼzozlanuvchi), „Majid“ (ulugʻ), 
„Bashir“ (bashorat beruvchi), 
„Nazir“ (ogohlantiruvchi) kabi soʻzlar bilan sifatlangan. 
Islom olamida Qurʼon musʼhaf nomi bilan ham mashhur. 
Islom ulamolari Qurʼonning 30 xil nom va sifatlarini sanab oʻtganlar.
➖➖➖➖➖➖➖➖➖➖➖➖
✍Quroning tuzulishi
➖➖➖➖➖➖➖➖➖➖➖➖
Qurʼonning boʻlimlari sura deyiladi,
uni shartli ravishda bob bilan taqqoslash mumkin.
Har sura oyatlarga boʻlingan. 
Qurʼon 114 sura, 6236 oyatdan iborat.
Har bir suraning oʻz nomi bor. Oyatlar esa tartib raqami bilan berilgan. 
Suralarning nomlari uning boshida kelgan soʻzdan olingan yoki zikri koʻproq kelgan narsalar,
voqealar yohud asosiy qahramon nomi bilan atalgan. 
Keyinchalik oʻqish va yodlash oson boʻlishi uchun Iroq hokimi Hajjoj ibn Yusuf (hukmronlik yillari 694—714) koʻrsatmasiga binoan Qurʼon 30 qism (arab.juz, fors. pora)ga boʻlingan.
Qurʼonda birinchi kelgan „Fotiha“ surasidan keyingi suralar katta, 
oʻrtacha va kichik suralar tartibida joylashgan. 2-Baqara surasi 286 oyatdan, eng qisqa Kavsar surasi 3 oyatdan iborat. 
Eng qisqa oyatlar „Toho“ va „Yosin“, eng uzun oyat „Baqara“ surasining 282-oyatidir. Suralar nozil boʻlish vaqti va joyiga koʻra 2 ga: hijradan oldin nozil boʻlgan suralar —
„Makka suralari“ (610—622 yillar, 90 sura) va hijradan keyin nozil boʻlgan suralar — „Madina suralari“ (622-yildan, 24 sura) ga ajratiladi.
Qurʼon matnining koʻp qismi Alloh bilan soʻzlashish, islom dushmanlari yoki undan ikkilanuvchilar bilan munozara qilish shaklida berilgan.
➖➖➖➖➖➖➖➖➖➖➖➖"
]);
}

if($tx=="🤲Ro'za Duosi"){
    bot('sendPhoto',[
        'chat_id'=>$chat_id,
'photo'=>"https://t.me/Hazars_City/8579",
'caption'=>"
——————————————————————
🌸Рузада огиз очиш ва йопиш дуолари

Руза тутиш (огиз епиш)
дуоси. Навайту ан асума
совма шахри ромазона
миннал фажри иллал
магриби холисал
лиллоху таолло Аллоху акбар. Амин.
РУЗА (огиз очиш) дуоси.
Аллохума лака сумту ва
бика аманту валайка
тавакалту ва алла
ризика ифтору фагфирли ла гафуру ма
кадамту ва мо ахарту.
Илохим Аллохим кабул
айласин рузангизни.
Амин🤲
————————————————————
",
        ]);
}


if($tx == "🔙Orqaga"){
bot('sendmessage',[ 
'chat_id'=>$chat_id,
'text'=>"
<b>🏠Bosh Menyuga Qaytdik
➖➖➖➖➖➖➖➖➖➖
▪️O'zizga kerakli
▫️Menyuni Tanlang
➖➖➖➖➖➖➖➖➖➖</b>",
'parse_mode'=>'html',
'reply_markup'=>$key1,
]);
}

if($tx=="🍃Juma Rasm"){
    bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"
🔔Assalomu Aleykum😇
 
🔳Bu Bolimda Siz O'ziznging 
✍ismingizni Yozib Ramazon Uchun 
🏞Rasm Yasashingiz Mumkun

🔊Hozir Bu Bo'limda: 4 Ta 
🖲STILDAGI Rasmlar 
Yasashingiz Mumkun😉
",
'parse_mode'=>'markdown',
'reply_markup'=> $key4,
     ]);
}

if($tx=="1️⃣  STIL"){
    bot('sendPhoto',[
        'chat_id'=>$chat_id,
'photo'=>"https://bezorii.xvest.ru/juma1/index.php?razmeri=125&eniga=580&boyiga=485&text=Meyliboy",
'caption'=>"
😇Bu 1 STILDAGI Rasm🏞 
 
🤨Shu Stilda Rasm😇 Kerak Bo'lsa
🔳Shu Tarzda: /Juma1 ismingiz

🔔Masalan: /Juma1 Meyliboy 
😇Shu Tarzda Botga ✍Jo'nating
",
        ]);
}

if($tx=="2️⃣  STIL"){
    bot('sendPhoto',[
        'chat_id'=>$chat_id,
'photo'=>"https://bezorii.xvest.ru/juma2/index.php?razmeri=125&eniga=280&boyiga=710&text=Meyliboy",
'caption'=>"
😇Bu 1 STILDAGI Rasm🏞 
 
🤨Shu Stilda Rasm😇 Kerak Bo'lsa
🔳Shu Tarzda: /Juma2 ismingiz

🔔Masalan: /Juma2 Meyliboy 
😇Shu Tarzda Botga ✍Jo'nating
",
        ]);
}

if(mb_stripos($tx,"/Juma1") !== false){ 
$ex = explode(" ",$tx);
bot('SendMessage',[
'chat_id'=>$chat_id, 'reply_to_message_id'=>$mid,
'text'=>"♻️Tayyorlanmoda Kuting...",
]);
bot('SendPhoto',[
'chat_id'=>$chat_id, 'reply_to_message_id'=>$mid,
'photo'=>"https://bezorii.xvest.ru/juma1/index.php?razmeri=125&eniga=580&boyiga=485&text=$ex[1]",
'caption'=>"
🔔Sizning Rasmingiz Tayyor✔

☺️Marxamat Bemalol

😇Glavnizga Qoyishiz Mumkun

",'reply_markup'=>json_encode(
['inline_keyboard' => [
[['text'=>'🤖Bot yaratish','url'=>'http://t.me/VipBuilder_UzBot']],
[['text'=>'🎧Bass Muzik🎸','url'=>'https://t.me/N1_Bass_Muziklar']],
[['text'=>'📱Telefonga Fonlar🏞','url'=>'https://t.me/Fonlani_Udari']],
 ]
]),
]);
}

if(mb_stripos($tx,"/Juma2") !== false){ 
$ex = explode(" ",$tx);
bot('SendMessage',[
'chat_id'=>$chat_id, 'reply_to_message_id'=>$mid,
'text'=>"♻️Tayyorlanmoda Kuting...",
]);
bot('SendPhoto',[
'chat_id'=>$chat_id, 'reply_to_message_id'=>$mid,
'photo'=>"https://bezorii.xvest.ru/juma2/index.php?razmeri=125&eniga=280&boyiga=710&text=$ex[1]",
'caption'=>"
🔔Sizning Rasmingiz Tayyor✔

☺️Marxamat Bemalol

😇Glavnizga Qoyishiz Mumkun

",'reply_markup'=>json_encode(
['inline_keyboard' => [
[['text'=>'🤖Bot yaratish','url'=>'http://t.me/VipBuilder_UzBot']],
[['text'=>'🎧Bass Muzik🎸','url'=>'https://t.me/N1_Bass_Muziklar']],
[['text'=>'📱Telefonga Fonlar🏞','url'=>'https://t.me/Fonlani_Udari']],
 ]
]),
]);
}

if($tx=="🦠Karonavirus Rasm"){
    bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"
🔔Assalomu Aleykum😇
 
🔳Bu Bolimda Siz O'ziznging 
✍ismingizni Yozib Karonavirus 
🏞Rasm Yasashingiz Mumkun

🔊Hozir Bu Bo'limda: 3 Ta 
🖲STILDAGI Rasmlar 
Yasashingiz Mumkun😉
",
'parse_mode'=>'markdown',
'reply_markup'=> $key3,
     ]);
}

if($tx=="1️⃣ STIL"){
    bot('sendPhoto',[
        'chat_id'=>$chat_id,
'photo'=>"https://bezorii.xvest.ru/karona1/index.php?razmeri=122&eniga=310&boyiga=605&text=ismingiz",
'caption'=>"
😇Bu 1 STILDAGI Rasm🏞 
 
🤨Shu Stilda Rasm😇 Kerak Bo'lsa
🔳Shu Tarzda: /Carona1 ismingiz

🔔Masalan: /Carona1 Meyliboy 
😇Shu Tarzda Botga ✍Jo'nating
",
        ]);
}

if($tx=="2️⃣ STIL"){
    bot('sendPhoto',[
        'chat_id'=>$chat_id,
'photo'=>"https://bezorii.xvest.ru/karona2/index.php?razmeri=125&eniga=280&boyiga=710&text=Meyliboy",
'caption'=>"
😇Bu 2 STILDAGI Rasm🏞 
 
🤨Shu Stilda Rasm😇 Kerak Bo'lsa
🔳Shu Tarzda: /Carona2 ismingiz

🔔Masalan: /Carona2 Meyliboy 
😇Shu Tarzda Botga ✍Jo'nating
",
        ]);
}

if($tx=="3️⃣ STIL"){
    bot('sendPhoto',[
        'chat_id'=>$chat_id,
'photo'=>"https://bezorii.xvest.ru/karona3/index.php?razmeri=125&eniga=280&boyiga=655&text=Meyliboy",
'caption'=>"
😇Bu 3 STILDAGI Rasm🏞 
 
🤨Shu Stilda Rasm😇 Kerak Bo'lsa
🔳Shu Tarzda: /Carona3 ismingiz

🔔Masalan: /Carona3 Meyliboy 
😇Shu Tarzda Botga ✍Jo'nating
",
        ]);
}

if(mb_stripos($tx,"/Carona1") !== false){ 
$ex = explode(" ",$tx);
bot('SendMessage',[
'chat_id'=>$chat_id, 'reply_to_message_id'=>$mid,
'text'=>"♻️Tayyorlanmoda Kuting...",
]);
bot('SendPhoto',[
'chat_id'=>$chat_id, 'reply_to_message_id'=>$mid,
'photo'=>"https://bezorii.xvest.ru/karona1/index.php?razmeri=122&eniga=310&boyiga=605&text=$ex[1]",
'caption'=>"
🔔Sizning Rasmingiz Tayyor✔

☺️Marxamat Bemalol

😇Glavnizga Qoyishiz Mumkun

",'reply_markup'=>json_encode(
['inline_keyboard' => [
[['text'=>'🤖Bot yaratish','url'=>'http://t.me/VipBuilder_UzBot']],
[['text'=>'🎧Bass Muzik🎸','url'=>'https://t.me/N1_Bass_Muziklar']],
[['text'=>'📱Telefonga Fonlar🏞','url'=>'https://t.me/Fonlani_Udari']],
 ]
]),
]);
}


if(mb_stripos($tx,"/Carona2") !== false){ 
$ex = explode(" ",$tx);
bot('SendMessage',[
'chat_id'=>$chat_id, 'reply_to_message_id'=>$mid,
'text'=>"♻️Tayyorlanmoda Kuting...",
]);
bot('SendPhoto',[
'chat_id'=>$chat_id, 'reply_to_message_id'=>$mid,
'photo'=>"https://bezorii.xvest.ru/karona2/index.php?razmeri=125&eniga=280&boyiga=710&text=$ex[1]",
'caption'=>"
🔔Sizning Rasmingiz Tayyor✔

☺️Marxamat Bemalol

😇Glavnizga Qoyishiz Mumkun

",'reply_markup'=>json_encode(
['inline_keyboard' => [
[['text'=>'🤖Bot yaratish','url'=>'http://t.me/VipBuilder_UzBot']],
[['text'=>'🎧Bass Muzik🎸','url'=>'https://t.me/N1_Bass_Muziklar']],
[['text'=>'📱Telefonga Fonlar🏞','url'=>'https://t.me/Fonlani_Udari']],
 ]
]),
]);
}


if(mb_stripos($tx,"/Carona3") !== false){ 
$ex = explode(" ",$tx);
bot('SendMessage',[
'chat_id'=>$chat_id, 'reply_to_message_id'=>$mid,
'text'=>"♻️Tayyorlanmoda Kuting...",
]);
bot('SendPhoto',[
'chat_id'=>$chat_id, 'reply_to_message_id'=>$mid,
'photo'=>"https://bezorii.xvest.ru/karona3/index.php?razmeri=125&eniga=280&boyiga=655&text=$ex[1]",
'caption'=>"
🔔Sizning Rasmingiz Tayyor✔

☺️Marxamat Bemalol

😇Glavnizga Qoyishiz Mumkun

",'reply_markup'=>json_encode(
['inline_keyboard' => [
[['text'=>'🤖Bot yaratish','url'=>'http://t.me/VipBuilder_UzBot']],
[['text'=>'🎧Bass Muzik🎸','url'=>'https://t.me/N1_Bass_Muziklar']],
[['text'=>'📱Telefonga Fonlar🏞','url'=>'https://t.me/Fonlani_Udari']],
 ]
]),
]);
}


if($tx=="😇Ramazon Rasm"){
    bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"
🔔Assalomu Aleykum😇
 
🔳Bu Bolimda Siz O'ziznging 
✍ismingizni Yozib Ramazon Uchun 
🏞Rasm Yasashingiz Mumkun

🔊Hozir Bu Bo'limda: 10 Ta 
🖲STILDAGI Rasmlar 
Yasashingiz Mumkun😉
",
'parse_mode'=>'markdown',
'reply_markup'=> $key2,
     ]);
}

if($tx=="1️⃣STIL"){
    bot('sendPhoto',[
        'chat_id'=>$chat_id,
'photo'=>"https://t.me/Hazars_City/8499",
'caption'=>"
😇Bu 1 STILDAGI Rasm🏞 
 
🤨Shu Stilda Rasm😇 Kerak Bo'lsa
🔳Shu Tarzda: /Ramazon1 ismingiz

🔔Masalan: /Ramazon1 Meyliboy 
😇Shu Tarzda Botga ✍Jo'nating
",
        ]);
}

if($tx=="2️⃣STIL"){
    bot('sendPhoto',[
        'chat_id'=>$chat_id,
'photo'=>"https://t.me/Hazars_City/8500",
'caption'=>"
😇Bu 2 STILDAGI Rasm🏞 
 
🤨Shu Stilda Rasm😇 Kerak Bo'lsa
🔳Shu Tarzda: /Ramazon2 ismingiz

🔔Masalan: /Ramazon2 Meyliboy 
😇Shu Tarzda Botga ✍Jo'nating
",
        ]);
}

if($tx=="3️⃣STIL"){
    bot('sendPhoto',[
        'chat_id'=>$chat_id,
'photo'=>"https://t.me/Hazars_City/8501",
'caption'=>"
😇Bu 3 STILDAGI Rasm🏞 
 
🤨Shu Stilda Rasm😇 Kerak Bolsa
🔳Shu Tarzda: /Ramazon3 ismingiz

🔔Masalan: /Ramazon3 Meyliboy 
😇Shu Tarzda Botga ✍Jo'nating
",
        ]);
}

if($tx=="4️⃣STIL"){
    bot('sendPhoto',[
        'chat_id'=>$chat_id,
'photo'=>"https://bezorii.xvest.ru/roza4/index.php?razmeri=97&eniga=366&boyiga=780&text=Meyliboy",
'caption'=>"
😇Bu 1 STILDAGI Rasm🏞 
 
🤨Shu Stilda Rasm😇 Kerak Bo'lsa
🔳Shu Tarzda: /Razmazon4 ismingiz

🔔Masalan: /Ramazon4 Meyliboy 
😇Shu Tarzda Botga ✍Jo'nating
",
        ]);
}

if($tx=="5️⃣STIL"){
    bot('sendPhoto',[
        'chat_id'=>$chat_id,
'photo'=>"https://bezorii.xvest.ru/roza5/index.php?razmeri=125&eniga=300&boyiga=670&text=Meyliboy",
'caption'=>"
😇Bu 1 STILDAGI Rasm🏞 
 
🤨Shu Stilda Rasm😇 Kerak Bo'lsa
🔳Shu Tarzda: /Razmazon5 ismingiz

🔔Masalan: /Ramazon5 Meyliboy 
😇Shu Tarzda Botga ✍Jo'nating
",
        ]);
}

if($tx=="6️⃣STIL"){
    bot('sendPhoto',[
        'chat_id'=>$chat_id,
'photo'=>"https://bezorii.xvest.ru/roza6/index.php?razmeri=125&eniga=280&boyiga=670&text=Meyliboy",
'caption'=>"
😇Bu 1 STILDAGI Rasm🏞 
 
🤨Shu Stilda Rasm😇 Kerak Bo'lsa
🔳Shu Tarzda: /Razmazon6 ismingiz

🔔Masalan: /Ramazon6 Meyliboy 
😇Shu Tarzda Botga ✍Jo'nating
",
        ]);
}

if($tx=="7️⃣STIL"){
    bot('sendPhoto',[
        'chat_id'=>$chat_id,
'photo'=>"https://bezorii.xvest.ru/roza7/index.php?razmeri=125&eniga=285&boyiga=663&text=Meyliboy",
'caption'=>"
😇Bu 1 STILDAGI Rasm🏞 
 
🤨Shu Stilda Rasm😇 Kerak Bo'lsa
🔳Shu Tarzda: /Razmazon7 ismingiz

🔔Masalan: /Ramazon7 Meyliboy 
😇Shu Tarzda Botga ✍Jo'nating
",
        ]);
}

if($tx=="8️⃣STIL"){
    bot('sendPhoto',[
        'chat_id'=>$chat_id,
'photo'=>"https://bezorii.xvest.ru/roza8/index.php?razmeri=125&eniga=285&boyiga=663&text=Meyliboy",
'caption'=>"
😇Bu 1 STILDAGI Rasm🏞 
 
🤨Shu Stilda Rasm😇 Kerak Bo'lsa
🔳Shu Tarzda: /Razmazon8 ismingiz

🔔Masalan: /Ramazon8 Meyliboy 
😇Shu Tarzda Botga ✍Jo'nating
",
        ]);
}

if($tx=="9️⃣STIL"){
    bot('sendPhoto',[
        'chat_id'=>$chat_id,
'photo'=>"https://bezorii.xvest.ru/roza9/index.php?razmeri=125&eniga=285&boyiga=663&text=Meyliboy",
'caption'=>"
😇Bu 1 STILDAGI Rasm🏞 
 
🤨Shu Stilda Rasm😇 Kerak Bo'lsa
🔳Shu Tarzda: /Razmazon9 ismingiz

🔔Masalan: /Ramazon9 Meyliboy 
😇Shu Tarzda Botga ✍Jo'nating
",
        ]);
}

if($tx=="🔟STIL"){
    bot('sendPhoto',[
        'chat_id'=>$chat_id,
'photo'=>"https://bezorii.xvest.ru/roza10/index.php?razmeri=125&eniga=285&boyiga=663&text=Meyliboy",
'caption'=>"
😇Bu 1 STILDAGI Rasm🏞 
 
🤨Shu Stilda Rasm😇 Kerak Bo'lsa
🔳Shu Tarzda: /Razmazon10 ismingiz

🔔Masalan: /Ramazon10 Meyliboy 
😇Shu Tarzda Botga ✍Jo'nating
",
        ]);
}

///Ramazon Photo Bolimi

if(mb_stripos($tx,"/Ramazon1") !== false){ 
$ex = explode(" ",$tx);
bot('SendMessage',[
'chat_id'=>$chat_id, 'reply_to_message_id'=>$mid,
'text'=>"♻️Tayyorlanmoda Kuting...",
]);
bot('SendPhoto',[
'chat_id'=>$chat_id, 'reply_to_message_id'=>$mid,
'photo'=>"https://bezorii.xvest.ru/roza2/index.php?razmeri=135&eniga=215&boyiga=710&text=$ex[1]",
'caption'=>"
🔔Sizning Rasmingiz Tayyor✔

☺️Marxamat Bemalol

😇Glavnizga Qoyishiz Mumkun

",'reply_markup'=>json_encode(
['inline_keyboard' => [
[['text'=>'🤖Bot yaratish','url'=>'http://t.me/VipBuilder_UzBot']],
[['text'=>'🎧Bass Muzik🎸','url'=>'https://t.me/N1_Bass_Muziklar']],
[['text'=>'📱Telefonga Fonlar🏞','url'=>'https://t.me/Fonlani_Udari']],
 ]
]),
]);
}

if(mb_stripos($tx,"/Ramazon2") !== false){ 
$ex = explode(" ",$tx);
bot('SendMessage',[
'chat_id'=>$chat_id, 'reply_to_message_id'=>$mid,
'text'=>"♻️Tayyorlanmoda Kuting...",
]);
bot('SendPhoto',[
'chat_id'=>$chat_id, 'reply_to_message_id'=>$mid,
'photo'=>"https://bezorii.xvest.ru/roza1/index.php?razmeri=135&eniga=206&boyiga=686&text=$ex[1]",
'caption'=>"
🔔Sizning Rasmingiz Tayyor✔

☺️Marxamat Bemalol

😇Glavnizga Qoyishiz Mumkun

",'reply_markup'=>json_encode(
['inline_keyboard' => [
[['text'=>'🤖Bot yaratish','url'=>'http://t.me/VipBuilder_UzBot']],
[['text'=>'🎧Bass Muzik🎸','url'=>'https://t.me/N1_Bass_Muziklar']],
[['text'=>'📱Telefonga Fonlar🏞','url'=>'https://t.me/Fonlani_Udari']],
 ]
]),
]);
}

if(mb_stripos($tx,"/Ramazon3") !== false){ 
$ex = explode(" ",$tx);
bot('SendMessage',[
'chat_id'=>$chat_id, 'reply_to_message_id'=>$mid,
'text'=>"♻️Tayyorlanmoda Kuting...",
]);
bot('SendPhoto',[
'chat_id'=>$chat_id, 'reply_to_message_id'=>$mid,
'photo'=>"https://bezorii.xvest.ru/roza3/index.php?razmeri=135&eniga=215&boyiga=755&text=$ex[1]",
'caption'=>"
🔔Sizning Rasmingiz Tayyor✔

☺️Marxamat Bemalol

😇Glavnizga Qoyishiz Mumkun

",'reply_markup'=>json_encode(
['inline_keyboard' => [
[['text'=>'🤖Bot yaratish','url'=>'http://t.me/VipBuilder_UzBot']],
[['text'=>'🎧Bass Muzik🎸','url'=>'https://t.me/N1_Bass_Muziklar']],
[['text'=>'📱Telefonga Fonlar🏞','url'=>'https://t.me/Fonlani_Udari']],
 ]
]),
]);
}

if(mb_stripos($tx,"/Ramazon4") !== false){ 
$ex = explode(" ",$tx);
bot('SendMessage',[
'chat_id'=>$chat_id, 'reply_to_message_id'=>$mid,
'text'=>"♻️Tayyorlanmoda Kuting...",
]);
bot('SendPhoto',[
'chat_id'=>$chat_id, 'reply_to_message_id'=>$mid,
'photo'=>"https://bezorii.xvest.ru/roza4/index.php?razmeri=97&eniga=366&boyiga=780&text=$ex[1]",
'caption'=>"
🔔Sizning Rasmingiz Tayyor✔

☺️Marxamat Bemalol

😇Glavnizga Qoyishiz Mumkun

",'reply_markup'=>json_encode(
['inline_keyboard' => [
[['text'=>'🤖Bot yaratish','url'=>'http://t.me/VipBuilder_UzBot']],
[['text'=>'🎧Bass Muzik🎸','url'=>'https://t.me/N1_Bass_Muziklar']],
[['text'=>'📱Telefonga Fonlar🏞','url'=>'https://t.me/Fonlani_Udari']],
 ]
]),
]);
}

if(mb_stripos($tx,"/Ramazon5") !== false){ 
$ex = explode(" ",$tx);
bot('SendMessage',[
'chat_id'=>$chat_id, 'reply_to_message_id'=>$mid,
'text'=>"♻️Tayyorlanmoda Kuting...",
]);
bot('SendPhoto',[
'chat_id'=>$chat_id, 'reply_to_message_id'=>$mid,
'photo'=>"https://bezorii.xvest.ru/roza5/index.php?razmeri=125&eniga=300&boyiga=670&text=$ex[1]",
'caption'=>"
🔔Sizning Rasmingiz Tayyor✔

☺️Marxamat Bemalol

😇Glavnizga Qoyishiz Mumkun

",'reply_markup'=>json_encode(
['inline_keyboard' => [
[['text'=>'🤖Bot yaratish','url'=>'http://t.me/VipBuilder_UzBot']],
[['text'=>'🎧Bass Muzik🎸','url'=>'https://t.me/N1_Bass_Muziklar']],
[['text'=>'📱Telefonga Fonlar🏞','url'=>'https://t.me/Fonlani_Udari']],
 ]
]),
]);
}

if(mb_stripos($tx,"/Ramazon6") !== false){ 
$ex = explode(" ",$tx);
bot('SendMessage',[
'chat_id'=>$chat_id, 'reply_to_message_id'=>$mid,
'text'=>"♻️Tayyorlanmoda Kuting...",
]);
bot('SendPhoto',[
'chat_id'=>$chat_id, 'reply_to_message_id'=>$mid,
'photo'=>"https://bezorii.xvest.ru/roza6/index.php?razmeri=125&eniga=280&boyiga=670&text=$ex[1]",
'caption'=>"
🔔Sizning Rasmingiz Tayyor✔

☺️Marxamat Bemalol

😇Glavnizga Qoyishiz Mumkun

",'reply_markup'=>json_encode(
['inline_keyboard' => [
[['text'=>'🤖Bot yaratish','url'=>'http://t.me/VipBuilder_UzBot']],
[['text'=>'🎧Bass Muzik🎸','url'=>'https://t.me/N1_Bass_Muziklar']],
[['text'=>'📱Telefonga Fonlar🏞','url'=>'https://t.me/Fonlani_Udari']],
 ]
]),
]);
}

if(mb_stripos($tx,"/Ramazon7") !== false){ 
$ex = explode(" ",$tx);
bot('SendMessage',[
'chat_id'=>$chat_id, 'reply_to_message_id'=>$mid,
'text'=>"♻️Tayyorlanmoda Kuting...",
]);
bot('SendPhoto',[
'chat_id'=>$chat_id, 'reply_to_message_id'=>$mid,
'photo'=>"https://bezorii.xvest.ru/roza7/index.php?razmeri=125&eniga=285&boyiga=663&text=$ex[1]",
'caption'=>"
🔔Sizning Rasmingiz Tayyor✔

☺️Marxamat Bemalol

😇Glavnizga Qoyishiz Mumkun

",'reply_markup'=>json_encode(
['inline_keyboard' => [
[['text'=>'🤖Bot yaratish','url'=>'http://t.me/VipBuilder_UzBot']],
[['text'=>'🎧Bass Muzik🎸','url'=>'https://t.me/N1_Bass_Muziklar']],
[['text'=>'📱Telefonga Fonlar🏞','url'=>'https://t.me/Fonlani_Udari']],
 ]
]),
]);
}

if(mb_stripos($tx,"/Ramazon8") !== false){ 
$ex = explode(" ",$tx);
bot('SendMessage',[
'chat_id'=>$chat_id, 'reply_to_message_id'=>$mid,
'text'=>"♻️Tayyorlanmoda Kuting...",
]);
bot('SendPhoto',[
'chat_id'=>$chat_id, 'reply_to_message_id'=>$mid,
'photo'=>"https://bezorii.xvest.ru/roza8/index.php?razmeri=125&eniga=285&boyiga=663&text=$ex[1]",
'caption'=>"
🔔Sizning Rasmingiz Tayyor✔

☺️Marxamat Bemalol

😇Glavnizga Qoyishiz Mumkun

",'reply_markup'=>json_encode(
['inline_keyboard' => [
[['text'=>'🤖Bot yaratish','url'=>'http://t.me/VipBuilder_UzBot']],
[['text'=>'🎧Bass Muzik🎸','url'=>'https://t.me/N1_Bass_Muziklar']],
[['text'=>'📱Telefonga Fonlar🏞','url'=>'https://t.me/Fonlani_Udari']],
 ]
]),
]);
}

if(mb_stripos($tx,"/Ramazon9") !== false){ 
$ex = explode(" ",$tx);
bot('SendMessage',[
'chat_id'=>$chat_id, 'reply_to_message_id'=>$mid,
'text'=>"♻️Tayyorlanmoda Kuting...",
]);
bot('SendPhoto',[
'chat_id'=>$chat_id, 'reply_to_message_id'=>$mid,
'photo'=>"https://bezorii.xvest.ru/roza9/index.php?razmeri=125&eniga=285&boyiga=663&text=$ex[1]",
'caption'=>"
🔔Sizning Rasmingiz Tayyor✔

☺️Marxamat Bemalol

😇Glavnizga Qoyishiz Mumkun

",'reply_markup'=>json_encode(
['inline_keyboard' => [
[['text'=>'🤖Bot yaratish','url'=>'http://t.me/VipBuilder_UzBot']],
[['text'=>'🎧Bass Muzik🎸','url'=>'https://t.me/N1_Bass_Muziklar']],
[['text'=>'📱Telefonga Fonlar🏞','url'=>'https://t.me/Fonlani_Udari']],
 ]
]),
]);
}

if(mb_stripos($tx,"/Ramazon10") !== false){ 
$ex = explode(" ",$tx);
bot('SendMessage',[
'chat_id'=>$chat_id, 'reply_to_message_id'=>$mid,
'text'=>"♻️Tayyorlanmoda Kuting...",
]);
bot('SendPhoto',[
'chat_id'=>$chat_id, 'reply_to_message_id'=>$mid,
'photo'=>"https://bezorii.xvest.ru/roza10/index.php?razmeri=125&eniga=285&boyiga=663&text=$ex[1]",
'caption'=>"
🔔Sizning Rasmingiz Tayyor✔

☺️Marxamat Bemalol

😇Glavnizga Qoyishiz Mumkun

",'reply_markup'=>json_encode(
['inline_keyboard' => [
[['text'=>'🤖Bot yaratish','url'=>'http://t.me/VipBuilder_UzBot']],
[['text'=>'🎧Bass Muzik🎸','url'=>'https://t.me/N1_Bass_Muziklar']],
[['text'=>'📱Telefonga Fonlar🏞','url'=>'https://t.me/Fonlani_Udari']],
 ]
]),
]);
}

if(mb_stripos($tx,"/ism") !== false){
    sleep("0.5");
$ex=explode(" ",$tx);
$ism = file_get_contents("https://ismlar.com/search/$ex[1]");
$exp = explode('<p class="text-size-5">',$ism);
$expl = explode('<div class="col-12 col-md-4 text-md-right">',$exp[1]);
$im = str_replace($expl[1],' ',$exp[1]);
$ims = str_replace('</p>',' ',$im);
$isms = str_replace('</div>',' ',$ims);
$ismn = str_replace('<div class="col-12 col-md-4 text-md-right">',' ',$isms);
$ismk = str_replace('&#039;','`',$ismn);
$ismm = trim("$ismk");
bot('SendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$mid,
'text'=>"📙<b>Ismlar Ma'nosi

🔖 $ex[1]

📑Manosi:</b> <i>$ismm</i>",
'parse_mode' => 'html'
    ]);
    sleep("0.5");
   }



if(mb_stripos($tx,"/start")!==false){

   $baza=file_get_contents("azo.dat");
   if(mb_stripos($baza,$chat_id) !==false){
   }else{
   $txt="\n$chat_id";
   $file=fopen("azo.dat","a");
   fwrite($file,$txt);
   fclose($file);
   }
}
if(mb_stripos($tx,"📊Statistika")!==false){
      $baza=file_get_contents("azo.dat");
      $all=substr_count($baza,"\n");
      $gr=substr_count($baza,"-");
      $us=$all-$gr;
      $txx = "
🌎 Hammasi: $all
├👤: $us
└👥: $gr

👤 - <b>Foydalanuvchilar</b>
👥 - <b>Guruhlar</b>

📆$sana ⏰$soat";
  bot('sendmessage',[
   'chat_id'=>$chat_id,
   'parse_mode'=>'html',
   'text'=>$txx,
  ]);
}

$bezori = $update->message;
$tx = $bezori->text;
$cid = $bezori->chat->id;

if ($tx == "📰Yangiliklar"){
$url = "https://daryo.uz/feed/";
$rss = simplexml_load_file($url);
foreach ($rss->channel->item as $item) {
$line = $item->title;
$link = $item->link;
}  
bot ('sendmessage', [
'chat_id'=> $cid,
'text'=>"
🔔Eng So'ngi 📰Yangiliklar

🆕️[$line]($link)

🍃Batafsil O'qish Uchun Bosing",
'parse_mode' =>"markdown",
]);
}

$bezori = $update->message;
$mid = $bezori->message_id;
$chat_id = $bezori->chat->id;

if(isset($message->new_chat_member) or isset($message->left_chat_member)){
 bot('deleteMessage',[
  'chat_id'=>$chat_id,
  'message_id'=>$mid,
    ]);
}


$bezori = $update->message;
$chat_id = $bezori->chat->id;
$mid = $bezori->message_id;

if($tx == "🎅Yangi Yil") {   
$kun1 = date('z',strtotime('3 hour')); 
$c2 = 364-$kun1;
$d = date('L',strtotime('3 hour'));
$b = $c2+$d;
$f = $b+81;
$e = $b+240;
$kun2 = date('H',strtotime('3 hour')); 
$b2 = 23-$kun2;
$kun3 = date('i',strtotime('3 hour')); 
$b3 = 59-$kun3;
$kun4 = date('s',strtotime('3 hour')); 
$b4 = 60-$kun4;
bot('sendmessage',[   
'chat_id'=>$chat_id,
'text'=>"
🎄Yangi yilga
├📆Kun *$b* 
├⏰Soat *$b2* 
├⌛Minut *$b3*  
└⏱Sekund *$b4* 🎅Qoldi

📆Hozir: $Sana ⏰$soat",
'parse_mode'=>"markdown",
'reply_to_message_id'=> $mid, 
]);   
}
if($tx == "/Panel" || $tx == "Panel"){
     bot('sendMessage',[
     'chat_id'=>$admin,
     'text'=>"
😁Assalomu Aleykum

👨‍💻[@$aminuser]
😎Admin Paneliga Xush Kelibsiz

◾Marxamat Pastdagi Menyulardan
⚠️O'zingizga Kerakligini Bosing",
     'reply_markup'=> $admkey,
     ]);
}
$tex = $message->text;
$lichka = file_get_contents("azo.dat");
$xabar = file_get_contents("send.txt");

if($tex=="📄Xabar Jo'natish" and $cid==$admin){
  bot('sendmessage',[
    'chat_id'=>$admin,
    'text'=>"
👥Userlarga Yuboriladigan 
📄Xabar Matnini Kiriting! 
🚫Bekor qilish uchun /cancel ni bosing.",
    'parse_mode'=>"html",
]); file_put_contents("send.txt","user");
}
if($xabar=="user" and $cid==$admin){
if($tx=="/cancel"){
   bot('sendmessage',[
    'chat_id'=>$admin,
    'text'=>"Bekor qilindi!",
    'parse_mode'=>"html",
]);
  file_put_contents("send.txt","");
}else{
  $lich = file_get_contents("azo.dat");
  $lichka = explode("\n",$lich);
  foreach($lichka as $lichkalar){
  $okuser=bot("sendmessage",[
    'chat_id'=>$lichkalar,
    'text'=>$tex,
    'parse_mode'=>'html'
]);
}
if($okuser){
  bot("sendmessage",[
    'chat_id'=>$admin,
    'text'=>"
👨‍💻Siz Yozgan Xabaringiz
👥Hamma Userlarga Yuborildi!",
    'parse_mode'=>'html',
]);
  file_put_contents("send.txt","");
}
}
}



$EN =   explode("/nick", $tx);
   if($EN[1]){
   $EN = str_replace('q', '•🇶', $EN);
   $EN = str_replace('w', '•🇼', $EN);
   $EN = str_replace('e', '•🇪', $EN);
   $EN = str_replace('r', '•🇷', $EN);
   $EN = str_replace('t', '•🇹', $EN);
   $EN = str_replace('y', '•🇾', $EN);
   $EN = str_replace('u', '•🇻', $EN);
   $EN = str_replace('i', '•🇮', $EN);
   $EN = str_replace('o', '•🇴', $EN);
   $EN = str_replace('p', '•🇵', $EN);
   $EN = str_replace('a', '•🇦', $EN);
   $EN = str_replace('s', '•🇸', $EN);
   $EN = str_replace('d', '•🇩', $EN);
   $EN = str_replace('f', '•🇫', $EN);
   $EN = str_replace('g', '•🇬', $EN);
   $EN = str_replace('h', '•🇭', $EN);
   $EN = str_replace('j', '•🇯', $EN);
   $EN = str_replace('k', '•🇰', $EN);
   $EN = str_replace('l', '•🇱', $EN);
   $EN = str_replace('z', '•🇿', $EN);
   $EN = str_replace('x', '•🇽', $EN);
   $EN = str_replace('c', '•🇨', $EN);
   $EN = str_replace('v', '•🇺', $EN);
   $EN = str_replace('b', '•🇧', $EN);
   $EN = str_replace('n', '•🇳', $EN);
   $EN = str_replace('m', '•🇲', $EN);
   bot('sendmessage',[
   'chat_id'=>$cid,
   'text'=>$EN[1],
 
    ]);
    }


?>