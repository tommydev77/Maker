<?
header('Content-Type: text/html; charset=utf-8');
date_default_timezone_set('Asia/Tashkent');

define('API_KEY','5255208851:AAFDzol0Ueelmt41OlaaktaFwBElXw6hXxs');
$Manager = "1989309538";
$company_name = "fayzlidev";
$api_url = "https://im-insta-api.herokuapp.com/info?url=";
$logging = false; // false yoki true json fleni yozadi
$channels = [
    [
        'chan_id' => "-1001720951969",
        'btn_text' => "Bizning kanal",
        'username' => "okuzbbot1",
        'required' => 1
    ],
    [
        'chan_id' => "-1001720951969",
        'btn_text' => "Bizning kanal",
        'username' => "okuzbbot1",
        'required' => 0
    ],
    [
        'chan_id' => "-1001720951969",
        'btn_text' => "Bizning kanal",
        'username' => "okuzbbot1",
        'required' => 0
    ]
]; 