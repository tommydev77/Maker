<?php
date_default_timezone_set('Asia/Tashkent');
define('TOKEN', '5290437157:AAHfw_IqXBVvvVyqIUAVGL2FaJBk5PpYZZ0');
$token = '5290437157:AAHfw_IqXBVvvVyqIUAVGL2FaJBk5PpYZZ0';
$admin = "1989309538"; 
$bot_username = "@faUseful_bot";
$kanal = '-1001667358131';
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".TOKEN."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}


$server = $_SERVER['SERVER_NAME'].$_SERVER['SCRIPT_NAME'];
file_get_contents("https://api.telegram.org/bot".TOKEN."/setwebhook?url=$server");
$botname = 'faUseful_bot';
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$cid = $message->chat->id;
$tx = $message->text;
$from_id = $update->message->from->id;
$mid = $message->message_id;
$name = $message->from->first_name;
$fid = $message->from->id;
$callback = $update->callback_query;
$message = $update->message;
$mid = $message->message_id;
$cal_query = $update->callback_query;
$data = $update->callback_query->data;
$type = $message->chat->type;
$text = $message->text;
$cid = $message->chat->id;
$uid= $message->from->id;
    $inlinequery = $update->inline_query;
    $inline_id = $inlinequery->id;
    $cal = $update->callback_query;
    $inlinesi = $cal->data;
    $cid2 = $cal->message->chat->id;
    $inlineid = $inlinequery->from->id;
    $inline_query = $inlinequery->query;
$gname = $message->chat->title;
$left = $message->left_chat_member;
$new = $message->new_chat_member;
$name = $message->from->first_name;
$repid = $message->reply_to_message->from->id;
$repname = $message->reply_to_message->from->first_name;
$newid = $message->new_chat_member->id;
$leftid = $message->left_chat_member->id;
$newname = $message->new_chat_member->first_name;
$leftname = $message->left_chat_member->first_name;
$username = $message->from->username;
$cmid = $update->callback_query->message->message_id;
$cusername = $message->chat->username;
$repmid = $message->reply_to_message->message_id; 
$ccid = $update->callback_query->message->chat->id;
$cfid = $update->callback_query->message->from->id;
$cuid = $update->callback_query->message->from->id;
$cqid = $update->callback_query->id;


$reply = $message->reply_to_message->text;
$nomer = $message->contact->phone_number;

$rpl = json_encode([
            'resize_keyboard'=>false,
            'force_reply'=>true,
            'selective'=>true
        ]);

$photo = $update->message->photo;
$gif = $update->message->animation;
$video = $update->message->video;
$music = $update->message->audio;
$voice = $update->message->voice;
$sticker = $update->message->sticker;
$document = $update->message->document;
$for = $message->forward_from;
$forc = $message->forward_from_chat;
$data = $callback->data;
$callid = $callback->id;
$cname = $calback->message->from->first_name;
$clname = $calback->message->from->last_name;
$lname = $message->from->last_name;
$ccid = $callback->message->chat->id;
$cmid = $callback->message->message_id;
$user = $message->from->username;
$inlinequery = $update->inline_query;
$inline_id = $inlinequery->id;
$inlineid = $inlinequery->from->id;
$inline_query = $inlinequery->query;
$chanel = '@php_foydali_kodlar';
$nameuz = "<a href='tg://user?id=$fid'>$name $lname</a>";


function joinchat($chatid){
    global $name, $cmid, $ccid, $chanel;
    $result = bot('getChatMember',[
    'chat_id'=>"$chanel",
    'user_id'=>$chatid
    ])->result->status;
   
    
    if($result == "creator" or $result == "administrator" or $result == "member" or 1){
        return true;
    } else {
        bot('deleteMessage',[
        'chat_id'=>$ccid,   
        'message_id'=>$cmid,
        ]); 
        bot('sendMessage',[
        'chat_id'=>$chatid,
        'text'=>"🔐 <b>$chanel ga obuna bo'lmasangiz botdan foydalana olmaysiz!</b>",
        'parse_mode'=>"html",
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
        [['text'=>"✅ Tekshirish",'callback_data'=>"tekshir"]]
        ]
        ])
        ]);
        return false;
    }
}


function step($id=0,$data=0) {
	file_put_contents('./step/'.$id.'.txt', $data);
}


function coin($id=0,$data=0) {
	file_put_contents('./coin/'.$id.'.txt', $data);
}

function get($get='') {
	return file_get_contents($get);
}



function put($url='', $data='') {
	file_put_contents($url,$data);
}

function send($text='') {
	bot('sendmessage', [
		'chat_id'=>$cid,
		'text'=>$text
	]);
}

if (!file_exists('step')) {
	mkdir('step');
}


if (!file_exists('coin')) {
	mkdir('coin');
}


if (!file_exists('coin/'.$fid)) {
	mkdir('coin/'.$fid);
}

if (!file_exists('coin/'.$fid.'/index.txt')) {	
	file_put_contents('coin/'.$fid.'/index.txt', '0');
}


if (!file_exists('user')) {
	mkdir('user');
}

if (!file_exists('webhook')) {
	mkdir('webhook');
}

if (!file_exists('webhook/'.$fid)) {
	mkdir('webhook/'.$fid);
}

if (!file_exists('user/'.$fid)) {
	mkdir('user/'.$fid);
}


if (!file_exists('referal')) {
	mkdir("referal");
}


if (!file_exists('statistika')) {
	mkdir("statistika");
}



if (!file_exists('statistika/users.txt')) {
	file_put_contents('statistika/users.txt', '');
}

if (!file_exists('narxlar/maincoin.txt')) {
	file_put_contents('narxlar/maincoin.txt', '0');
}


if (!file_exists('referal/'.$fid.'.txt')) {
	file_put_contents('referal/'.$fid.'.txt', '');
}

if (!file_exists('ban')) {	
	mkdir('ban/');
}

if (!file_exists('ban/banid.txt')) {
	file_put_contents('ban/banid.txt', '');
}

if (!file_exists('narxlar')) {	
	mkdir('narxlar');
}

if (!file_exists('narxlar/pullik_narx.txt')) {
	file_put_contents('narxlar/pullik_narx.txt', '0');
}
if (!file_exists('narxlar/pro_narx.txt')) {
	file_put_contents('narxlar/pro_narx.txt', '0');
}

if ( !in_array($fid, explode("\n",file_get_contents('statistika/users.txt') ) ) ) {
	file_put_contents('statistika/users.txt', "\n$fid", FILE_APPEND);
	bot('sendmessage', [
		'chat_id'=>$kanal,
		'text'=>"😄 Yangi aʼzo
👤 Ismi: $name
🆔 raqami: $fid
✳️ Usernamesi: $username
💡 Lichka: $nameuz
💡 Telefon raqami: $nomer",	
		'parse_mode'=>'html'
	]);
}





$getstep = file_get_contents('step/'.$fid.'.txt');
$getcoin = intval(file_get_contents('coin/'.$fid.'/index.txt')) ? intval(file_get_contents('coin/'.$fid.'/index.txt')) : 0;
$users = count(explode("\n", get('statistika/users.txt'))) - 1 ? count(explode("\n", get('statistika/users.txt'))) - 1 : 0;
$createdFreeBots = intval(get('statistika/freebots.txt')) ? intval(get('statistika/freebots.txt')) : 0;
$createdMoneyBots = intval(get('statistika/moneybots.txt')) ? intval(get('statistika/moneybots.txt')) : 0;
$createdProBots = intval(get('statistika/probots.txt')) ? intval(get('statistika/probots.txt')) : 0;
$createdBots = $createdProBots + $createdFreeBots + $createdMoneyBots;
$getban = file_get_contents('ban/banid.txt');
$maincoin = file_get_contents('narxlar/maincoin.txt');
$pullik_narx = file_get_contents('narxlar/pullik_narx.txt');
$pro_narx = file_get_contents('narxlar/pro_narx.txt');

function putfree() {
	$pull = intval(get('statistika/freebots.txt')) + 1;
	file_put_contents('statistika/freebots.txt', $pull);
} 

function putmoney() {
	$pull = intval(get('statistika/moneybots.txt')) + 1;
	file_put_contents('statistika/moneybots.txt', $pull);
} 
function putpro() {
	$pull = intval(get('statistika/probots.txt')) + 1;
	file_put_contents('statistika/probots.txt', $pull);
} 

$mainBtn = json_encode([
	'resize_keyboard'=>true,
	'keyboard'=>[
		[['text'=>"🛠 Bot yaratish"]],
		[['text'=>"♻️ Webhook"],['text'=>"🗂 Host"]],
		[['text'=>"🌄 Ob havo"],['text'=>"🔂 Translate"]],
		[['text'=>"🔲 QR CODE"],['text'=>"🖼 Rasm izlash"]],	
		[['text'=>"🌌 TikTokdan video yuklash"]],	
		[['text'=>"🌆 Instagramdan video yuklash"]],	
		[['text'=>"🎇 Youtubedan video yuklash"]],	
		[['text'=>"📚 Ismlar manosi"]],	
		[['text'=>"🖌 Adminga xabar"],['text'=>"📊 Statistika"]],
		[['text'=>"👨🏻‍💻 Admin"]],	
	]
]);



$whatKind_btns = json_encode([
	'inline_keyboard'=>[
		[['text'=>"🆓 Bepul bo`lim",'callback_data'=>"free"],],
		[['text'=>"💶 Pullik bo`lim",'callback_data'=>"money"],],
		[['text'=>"🛡 Pro bo`lim",'callback_data'=>"pro"],],
		[['text'=>"◀️Orqaga",'callback_data'=>"menucreatebot"]]
	]
]);


$creatbotBtn = json_encode([
	'inline_keyboard'=>[
		[['text'=>"➕ Yangi bot ochish",'callback_data'=>"newbot"],],
		[['text'=>"⚙️ Botlarni sozlash",'callback_data'=>"settingbot"],],
		[['text'=>"☣️ Coin ishlash",'callback_data'=>"workcoin"],],
		[['text'=>"📲 Kabinet",'callback_data'=>"kabinet"],],
		[['text'=>"◀️Ortga",'callback_data'=>"menu"]]
	]
]);

$workcoin = json_encode([
	'inline_keyboard'=>[
		[['text'=>"✴️ Referal orqali",'callback_data'=>"withreferal"],],
		[['text'=>"💶 Paynet orqali",'callback_data'=>"withpaynet"],],
		[['text'=>"◀️Ortga",'callback_data'=>"menucreatebot"]]
	]
]); 

$tekin = json_encode([
	'inline_keyboard'=>[
		[['text'=>"✅ Nik bot v0.3 bot",'callback_data'=>"freenikbot"],['text'=>"🕋Quron bot",'callback_data'=>"freekaranbot"]],
		[['text'=>"🚫Spam Bot",'callback_data'=>"freespambot"],['text'=>"📦Zip Create",'callback_data'=>"freezipbot"]],
		[['text'=>"⛔Join Bot",'callback_data'=>"freejoinbot"],['text'=>"❄️Azo Bot",'callback_data'=>"freememberbot"]],
		[['text'=>"📝Konspekt",'callback_data'=>"freekonspectbot"]],
		[['text'=>"◀️Ortga",'callback_data'=>"back"]]
	]
]);


$pullik = json_encode([
'inline_keyboard'=>[
	[['text'=>"💰Money v0.3",'callback_data'=>"money_v3"],['text'=>"👤Obunachi v0.1",'callback_data'=>"member_v1"]],
	[['text'=>"💶 Rubl Bot v0.3",'callback_data'=>"rubl_v1"],['text'=>"👤Obunachi v0.2",'callback_data'=>"member_v2"]],
	[['text'=>"👮‍♂️Posbon bot",'callback_data'=>"oxranbot"],['text'=>"💶 Rubl Bot v0.4",'callback_data'=>"rubl_v2"]],
	[['text'=>"👤Obunachi v0.3",'callback_data'=>"member_v3"],],
	[['text'=>"◀️Ortga",'callback_data'=>"back"]]
]
]);


$can = json_encode([
'inline_keyboard'=>[
	[['text'=>"◀️ Orqaga",'callback_data'=>"cancel"]]
]
]);


$pro_menu = json_encode([
	'inline_keyboard'=>[
		[['text'=>"❄AvtoNakrutka",'callback_data'=>"avtonakbot"],['text'=>"❄Logo Bot",'callback_data'=>"logobot"]],
		[['text'=>"💰Pul bot (rubl)",'callback_data'=>"rublbot"],['text'=>"💰Pul bot (so'm)",'callback_data'=>"sombot"]],
	    [['text'=>"📦Uc bot",'callback_data'=>"ucbot"],['text'=>"🇺🇸Usa bot",'callback_data'=>"usabot"]],
	    [['text'=>"📦BC bot",'callback_data'=>"bcbot"],['text'=>"📦MB bot",'callback_data'=>"mbbot"]],
		[['text'=>"◀️Ortga",'callback_data'=>"back"]] 
	]
]);



if ($message or $cal_query) {
	if($data == "tekshir"){
	    if(joinchat($ccid) == true){
	        bot('deleteMessage',[
	        'chat_id'=>$cid,
	        'message_id'=>$cmid
	        ]); 
	    }



	}

	if (joinchat($fid)) {
		if (mb_stripos($getban, $fid) !== false) {
		    bot('sendMessage', [
				'chat_id'=>$cid,
				'parse_mode'=>"html",

				'text'=>"<b>🖐Salom <a href='tg:user?id=$cid'>$name</a> \nSiz ⛔️ Botimizdan foydalana olmaysiz, chunki Bot sizni bloklangan!!!\nBlokdan chiqish uchun ADMIN ga yozing! Blokdan chiqmaguncha bot siz uchun ishlamaydi!!!🚫!</b> " ,

				'reply_markup'=>json_encode([
					'inline_keyboard'=>[
						[['text'=>"Admin👨‍💻","url"=>"@fayzliDev"]],
					]
				])
			]);

			exit();
		} else {
			if ($text == '/start') {
				bot('sendmessage', [
					'chat_id'=>$cid,
					'text'=>'<b> 🖐Salom, botimizga xush kelibsiz. </b>'."\n\n🖥 Siz asosiy menyudasiz",
					'parse_mode'=>'html',
					'reply_markup'=> $mainBtn
				]);
			}

			if ($text=='🛠 Bot yaratish') {
				step($fid,'');
				file_put_contents('./user/'.$fid.'/step.txt', 'createbot');
				bot('sendmessage', [
					'chat_id' => $cid,
					'text'=>'<b> 🤖 Bot menyusi: </b>',
					'parse_mode'=>'html',
					'reply_markup'=>$creatbotBtn,
				]);
			}



			if ($text=='📊 Statistika') {
				bot('sendmessage', [
					'chat_id' => $cid,
					'text'=>"<b>📊 Statistika:  </b> \n\nAzolar: $users\n\nJami yaratilgan botlar: $createdBots\n\nJami yaratilgan tekin botlar: $createdFreeBots\n\nJami yaratilgan pullik botlar: $createdMoneyBots\n\nJami yaratilgan pro botlar: $createdProBots",
					'parse_mode'=>'html',
					'reply_markup'=>$main,
				]);
			}

			if ($text=='👨🏻‍💻 Admin') {
				bot('sendmessage', [
					'chat_id' => $cid,
					'text'=>"<b>👨🏻‍💻 Admin ismi: Fayozbek </b> \n\n👨🏻‍💻 ID: $admin\n\n👨🏻‍💻 Username: @fayziDev",
					'parse_mode'=>'html',
					'reply_markup'=>$main,
				]);
			}



			if ($data == 'menu') {
				file_put_contents('./user/'.$fid.'/step.txt', '');
				step($ccid,'');
		        bot('deleteMessage',[
			        'chat_id'=>$ccid,
			        'message_id'=>$cmid
		        ]); 
				bot('sendmessage', [
					'chat_id'=>$ccid,
					'text'=>"<b> 🖥 Siz asosiy menyudasiz </b>",
					'parse_mode'=>'html',
					'reply_markup'=> $mainBtn
				]);
			}

			if ($data == 'newbot') {
				file_put_contents('./user/'.$fid.'/step.txt', 'newbot');
				step($ccid,'');
		        bot('editMessageText',[
			        'chat_id'=>$ccid,
			        'message_id'=>$cmid,
			        'text'=>"*📋Quyidagilardan birini tanlang:*",
					'parse_mode'=>"Markdown",
			        'reply_markup'=> $whatKind_btns
				]);	
			}

			if ($data == 'free') {
				file_put_contents('./user/'.$fid.'/step.txt', 'tekin');
				step($ccid,'');
		        bot('editMessageText',[
			        'chat_id'=>$ccid,
			        'message_id'=>$cmid,
			        'text'=>"*Bepul bo'lim: *",
					'parse_mode'=>"Markdown",
			        'reply_markup'=> $tekin
				]);	
			}

			if ($data == 'money') {
				file_put_contents('./user/'.$fid.'/step.txt', 'pullik');
				step($ccid,'');
		        bot('editMessageText',[
			        'chat_id'=>$ccid,
			        'message_id'=>$cmid,
			        'text'=>"*Pullik bo'lim: *",
					'parse_mode'=>"Markdown",
			        'reply_markup'=> $pullik
				]);	
			}


			if ($data == 'pro') {
				step($ccid,'');
				file_put_contents('./user/'.$fid.'/step.txt', 'pro_menu');
		        bot('editMessageText',[
			        'chat_id'=>$ccid,
			        'message_id'=>$cmid,
			        'text'=>"*Pro bo'lim: *",
					'parse_mode'=>"Markdown",
			        'reply_markup'=> $pro_menu
				]);	
			}


			if ($data == 'menucreatebot') {
				step($ccid,'');
				file_put_contents('./user/'.$fid.'/step.txt', 'createbotBtn');	
				bot('editMessageText',[
			        'chat_id'=>$ccid,
			        'message_id'=>$cmid,
			        'text'=>"* 🤖 Bot menyusi: *",
					'parse_mode'=>"Markdown",
			        'reply_markup'=> $creatbotBtn
				]);	
			}


			if ($data == 'back') {
				step($ccid,'');
				file_put_contents('./user/'.$fid.'/step.txt', 'newbot');
		        bot('editMessageText',[
			        'chat_id'=>$ccid,
			        'message_id'=>$cmid,
			        'text'=>"*📋Quyidagilardan birini tanlang:*",
					'parse_mode'=>"Markdown",
			        'reply_markup'=> $whatKind_btns
				]);		
			}

			if ($data == 'cancel') {
				mb_stripos($getstep, '&token') !==false ? step($ccid, '') :  step($ccid, $getstep);
		        bot('editMessageText',[
			        'chat_id'=>$ccid,
			        'message_id'=>$cmid,
			        'text'=>"*📋Quyidagilardan birini tanlang:*",
					'parse_mode'=>"Markdown",
			        'reply_markup'=> $whatKind_btns
				]);	
			}






			if ($data == 'workcoin') {
				file_put_contents('./user/'.$fid.'/step.txt', 'workcoin');
		        bot('editMessageText',[
			        'chat_id'=>$ccid,
			        'message_id'=>$cmid,
			        'text'=>"*📋Quyidagilardan birini tanlang:*",
					'parse_mode'=>"Markdown",
			        'reply_markup'=> $workcoin
				]);	
			}


			if ($data == 'withreferal') {
				file_put_contents('./user/'.$fid.'/step.txt', 'withreferal');	
				bot('editMessageText',[
			        'chat_id'=>$ccid,
			        'message_id'=>$cmid,
			        'text'=>"🌐 Ushbu referal linkini do`stingizga yuboring va $maincoin ta coin hisobingizga qo`shiladi \n\nhttps://t.me/FaUseful_bot?start=$ccid ",
			        'reply_markup'=>json_encode([
						'inline_keyboard'=>[
							[['text'=>"◀️Orqaga",'callback_data'=>"menuworkcoin"]]
						]
					])
				]);	
			}


			if ($data == 'withpaynet') {
				file_put_contents('./user/'.$fid.'/step.txt', 'withpaynet');	
				bot('editMessageText',[
			        'chat_id'=>$ccid,
			        'message_id'=>$cmid,
			        'text'=>"🌐 Paynet qilish uchun @fayzlidev ga murojat qiling ! ",
			        'reply_markup'=>json_encode([
						'inline_keyboard'=>[
							[['text'=>"◀️Orqaga",'callback_data'=>"menuworkcoin"]]
						]
					])
				]);	
			}


			if ($data == 'menuworkcoin') {
				file_put_contents('./user/'.$fid.'/step.txt', 'workcoin');
		        bot('editMessageText',[
			        'chat_id'=>$ccid,
			        'message_id'=>$cmid,
			        'text'=>"*📋Quyidagilardan birini tanlang:*",
					'parse_mode'=>"Markdown",
			        'reply_markup'=> $workcoin
				]);	
			}







		if($data == 'settingbot'){
			bot('editMessageText',[
			   'chat_id'=>$ccid,
			   'text'=>"
			
			❗️Botni o'chirish uchun shunchaki quyidagi amalni to'g'ri bajaring👇

			/del BOT TOKEN

			🧩Namuna:
			/del 755174882:AAGemn6my3SZrp_IWFzq7xNMo2GcoQ5g8F0
			",
			   'reply_markup'=>json_encode([
						'inline_keyboard'=>[
							[['text'=>"◀️Orqaga",'callback_data'=>"menucreatebot"]]
						]
					]), 
			   'parse_mode' => 'html',
			   'message_id'=>$cmid
			   
			]);
		}


		if(mb_stripos($tx, "/del")!==false){
			$ex=explode(" ", $tx);
			$px=$ex[1];
			file_get_contents("https://api.telegram.org/bot$px/deletewebhook");
			$to = file_get_contents("https://api.telegram.org/bot$px/getme");
			$json = json_decode($to);
			$botus = $json->result->username;
			bot('sendmessage',[
			   'chat_id'=>$cid,
			   'text'=>"❗️Bot muvaffaqiyatli o'chirildi❗️

			🔰Botingiz manzili: @$botus 👈
			",
			   'parse_mode' => 'html',
			   'reply_markup'=>$back_menu,   
			]);

		}





		if (mb_stripos($tx, '/start')!==false and isset(explode(' ', $tx)[1]) ) {
			if (explode(' ', $tx)[1] == $fid) {
				bot('sendmessage',[
				   'chat_id'=>$fid,
				   'text'=>"💥 Siz o`zingizni botga referal orqali taklif qila olmaysiz.",
				]);
			}

			else {
				if (mb_stripos(get('statistika/users.txt'), $fid)!==false) {}
				else {
					bot('sendmessage',[
					   'chat_id'=>explode(' ', $tx)[1],
					   'text'=>"Siz do`stingizni taklif qilganingiz uchun sizga $maincoin ta coin berildi.",
					]);

					file_put_contents('./coin/'.explode(' ', $tx)[1]."/index.txt", file_get_contents("./coin/${explode(' ', $tx)[1]}/index.txt") + $maincoin);
				}
			}




			bot('sendmessage', [
				'chat_id'=>$cid,
				'text'=>'<b> 🖐Salom, botimizga xush kelibsiz. </b>'."\n\n🖥 Siz asosiy menyudasiz",
				'parse_mode'=>'html',
				'reply_markup'=> $mainBtn
			]);
		}



		if ($data == 'kabinet') {
			$getcoin = file_get_contents("./coin/$ccid/index.txt") ? file_get_contents("./coin/$ccid/index.txt") : 0;
			file_put_contents('./user/'.$fid.'/step.txt', 'kabinet');
	        bot('editMessageText',[
		        'chat_id'=>$ccid,
		        'message_id'=>$cmid,
		        'text'=>"*🛠 Kabinet:* \n\n👤Sizning ID: $ccid

💰 Sizda $getcoin ta coin mavjud

💵 Referal narxi: $maincoin ta coin

📔 Pullik bot oladigan coin miqdori: $pullik_narx

📔 Pro bot oladigan coin miqdori: $pro_narx

🇺🇿Admin : @fayzlidev",
				'parse_mode'=>"Markdown",
			        'reply_markup'=>json_encode([
						'inline_keyboard'=>[
							[['text'=>"◀️Orqaga",'callback_data'=>"menucreatebot"]]
						]
					])
			]);	
		}
			
			# ------------------FAYZLIDEV----------------------  FREE NIK BOT ---------------------------------FAYZLIDEV------------ #



			if($data== "freenikbot"){
			    step($ccid,"freenikbot&token");

		        bot('editMessageText',[
			        'chat_id'=>$ccid,
			        'message_id'=>$cmid,
			        'text'=>"*@BotFather-ga o'ting.  Botingiz tokenini jo‘nating

💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA*",
					'parse_mode'=>"Markdown",
			        'reply_markup'=> $can
				]);	
			}

			if($data== "freekaranbot"){
			    step($ccid,"freekaranbot&token");

		        bot('editMessageText',[
			        'chat_id'=>$ccid,
			        'message_id'=>$cmid,
			        'text'=>"*@BotFather-ga o'ting.  Botingiz tokenini jo‘nating

💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA*",
					'parse_mode'=>"Markdown",
			        'reply_markup'=> $can
				]);	
			}

			if($data== "freespambot"){
			    step($ccid,"freespambot&token");

		        bot('editMessageText',[
			        'chat_id'=>$ccid,
			        'message_id'=>$cmid,
			        'text'=>"*@BotFather-ga o'ting.  Botingiz tokenini jo‘nating

💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA*",
					'parse_mode'=>"Markdown",
			        'reply_markup'=> $can
				]);	
			}
			
			if($data== "freezipbot"){
			    step($ccid,"freezipbot&token");

		        bot('editMessageText',[
			        'chat_id'=>$ccid,
			        'message_id'=>$cmid,
			        'text'=>"*@BotFather-ga o'ting.  Botingiz tokenini jo‘nating

💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA*",
					'parse_mode'=>"Markdown",
			        'reply_markup'=> $can
				]);	
			}

			if($data== "freejoinbot"){
			    step($ccid,"freejoinbot&token");

		        bot('editMessageText',[
			        'chat_id'=>$ccid,
			        'message_id'=>$cmid,
			        'text'=>"*@BotFather-ga o'ting.  Botingiz tokenini jo‘nating

💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA*",
					'parse_mode'=>"Markdown",
			        'reply_markup'=> $can
				]);	
			}


			if($data== "freememberbot"){
			    step($ccid,"freememberbot&token");

		        bot('editMessageText',[
			        'chat_id'=>$ccid,
			        'message_id'=>$cmid,
			        'text'=>"*@BotFather-ga o'ting.  Botingiz tokenini shu ko`rinishda jo‘nating:

KANALINGIZ USERNAMEmi			        
126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA*",
					'parse_mode'=>"Markdown",
			        'reply_markup'=> $can
				]);	
			}




			if($data== "freekonspectbot"){
			    step($ccid,"freekonspectbot&token");

		        bot('editMessageText',[
			        'chat_id'=>$ccid,
			        'message_id'=>$cmid,
			        'text'=>"*@BotFather-ga o'ting.  Botingiz tokenini jo‘nating

💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA*",
					'parse_mode'=>"Markdown",
			        'reply_markup'=> $can
				]);	
			}



// -------------------------------------------------------------------------------------------------------------------

			// 1
			if ( file_get_contents('./step/'.$fid.'.txt') == 'freenikbot&token' ) {
				$getMe = json_decode(get("https://api.telegram.org/bot$tx/getMe"));
				$nBot = 'freenikbot';
				if ($getMe->ok == 200) {
					bot('sendmessage', [
						'chat_id'=>$cid,
						'text'=>'Tayyorlanmoqda...'
					]);

				    $kod = file_get_contents("free/$nBot.php");
				    $kod = str_replace("API_TOKEN", "$tx", $kod);
				    $kod = str_replace("ADMIN_ID", "$fid", $kod);
					$kod = str_replace("ADMIN_USER", "$user", $kod);
					mkdir("bots");
					mkdir("bots/$fid");
				    mkdir("bots/$fid/$nBot");
				    if(file_get_contents("bots/$fid/$nBot/$nBot.php")){
				        unlink("bots/$fid/$nBot/strtotime.php");
				        unlink("bots/$fid/$nBot/usid.txt");
				        unlink("bots/$fid/$nBot/grid.txt");
				        $files = glob("bots/$fid/$nBot/baza/*");
				        foreach ($files as $key) {
				        	unlink($key);
				        }
				        rmdir("bots/$fid/$nBot/baza");
				    }
    				file_put_contents("bots/$fid/$nBot/$nBot.php", $kod);
  					$get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/PHP/fayozbek/bots/$fid/$nBot/$nBot.php"))->result;


					$user = $getMe->result->username;
					$nomi = $getMe->result->first_name;
					$idsi = $getMe->result->id;


  					if ($get) {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);


				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'message_id'=>$getid,
					        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Tekin\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $idsi\n\n/panel - admin panel",
					        'parse_mode'=>"html",
					        'reply_markup'=>$mainBtn
				        ]);	


				        bot('sendMessage',[
					        'chat_id'=>$kanal,
					        'text'=>"💡 Diqqat yangi bot yaratildi 💡


💡 Bot turi: Tekin

🤖 Bot nomi $nomi 

🤖 Useri $user 

🗄 Id raqami $idsi 

🧑‍💻Yaratuvchi $nameuz 

⏳ ".date("Y-m-d H:i:s"),
					        'parse_mode'=>"html",
				        ]);	


				        putfree();					
  					} else {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);

				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'text'=>"📛 Noma'lum xatolik",
					        'parse_mode'=>"html"
				        ]);
          			}


				} else {
					bot('sendmessage', [
						'text'=>"📛 Menimcha siz tokenni yuborishda xatolikka yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!", 
						'chat_id'=>$cid, 
						'reply_markup'=>$mainBtn
					]);

				}

				step($fid, '');
			}


			// 2
			if ( file_get_contents('./step/'.$fid.'.txt') == 'freekaranbot&token' ) {
				$getMe = json_decode(get("https://api.telegram.org/bot$tx/getMe"));
				$nBot = 'freekaranbot';
				if ($getMe->ok == 200) {
					bot('sendmessage', [
						'chat_id'=>$cid,
						'text'=>'Tayyorlanmoqda...'
					]);

				    $kod = file_get_contents("free/$nBot.php");
				    $kod = str_replace("API_TOKEN", "$tx", $kod);
				    $kod = str_replace("ADMIN_ID", "$fid", $kod);
					$kod = str_replace("ADMIN_USER", "$user", $kod);
					mkdir("bots");
					mkdir("bots/$fid");
				    mkdir("bots/$fid/$nBot");
				    if(file_get_contents("bots/$fid/$nBot/$nBot.php")){
				        unlink("bots/$fid/$nBot/strtotime.php");
				        unlink("bots/$fid/$nBot/usid.txt");
				        unlink("bots/$fid/$nBot/grid.txt");
				        $files = glob("bots/$fid/$nBot/baza/*");
				        foreach ($files as $key) {
				        	unlink($key);
				        }
				        rmdir("bots/$fid/$nBot/baza");
				    }
    				file_put_contents("bots/$fid/$nBot/$nBot.php", $kod);
  					$get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/PHP/fayozbek/bots/$fid/$nBot/$nBot.php"))->result;


					$user = $getMe->result->username;
					$nomi = $getMe->result->first_name;
					$idsi = $getMe->result->id;


  					if ($get) {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);


				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'message_id'=>$getid,
					        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Tekin\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $idsi\n\n/panel - admin panel",
					        'parse_mode'=>"html",
					        'reply_markup'=>$mainBtn
				        ]);		



				        bot('sendMessage',[
					        'chat_id'=>$kanal,
					        'text'=>"💡 Diqqat yangi bot yaratildi 💡


💡 Bot turi: Tekin

🤖 Bot nomi $nomi 

🤖 Useri $user 

🗄 Id raqami $idsi 

🧑‍💻Yaratuvchi $nameuz 

⏳ ".date("Y-m-d H:i:s"),
					        'parse_mode'=>"html",
				        ]);	


				        putfree();				
  					} else {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);

				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'text'=>"📛 Noma'lum xatolik",
					        'parse_mode'=>"html"
				        ]);
          			}


				} else {
					bot('sendmessage', [
						'text'=>"📛 Menimcha siz tokenni yuborishda xatolikka yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!", 
						'chat_id'=>$cid, 
						'reply_markup'=>$mainBtn
					]);

				}

				step($fid, '');
			}




			// 3
			if ( file_get_contents('./step/'.$fid.'.txt') == 'freespambot&token' ) {
				$getMe = json_decode(get("https://api.telegram.org/bot$tx/getMe"));
				$nBot = 'freespambot';
				if ($getMe->ok == 200) {
					bot('sendmessage', [
						'chat_id'=>$cid,
						'text'=>'Tayyorlanmoqda...'
					]);

				    $kod = file_get_contents("free/$nBot.php");
				    $kod = str_replace("API_TOKEN", "$tx", $kod);
				    $kod = str_replace("ADMIN_ID", "$fid", $kod);
					$kod = str_replace("ADMIN_USER", "$user", $kod);
					mkdir("bots");
					mkdir("bots/$fid");
				    mkdir("bots/$fid/$nBot");
				    if(file_get_contents("bots/$fid/$nBot/$nBot.php")){
				        unlink("bots/$fid/$nBot/strtotime.php");
				        unlink("bots/$fid/$nBot/usid.txt");
				        unlink("bots/$fid/$nBot/grid.txt");
				        $files = glob("bots/$fid/$nBot/baza/*");
				        foreach ($files as $key) {
				        	unlink($key);
				        }
				        rmdir("bots/$fid/$nBot/baza");
				    }
    				file_put_contents("bots/$fid/$nBot/$nBot.php", $kod);
  					$get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/PHP/fayozbek/bots/$fid/$nBot/$nBot.php"))->result;


					$user = $getMe->result->username;
					$nomi = $getMe->result->first_name;
					$idsi = $getMe->result->id;


  					if ($get) {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);


				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'message_id'=>$getid,
					        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Tekin\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $idsi\n\n/panel - admin panel",
					        'parse_mode'=>"html",
					        'reply_markup'=>$mainBtn
				        ]);						




				        bot('sendMessage',[
					        'chat_id'=>$kanal,
					        'text'=>"💡 Diqqat yangi bot yaratildi 💡


💡 Bot turi: Tekin

🤖 Bot nomi $nomi 

🤖 Useri $user 

🗄 Id raqami $idsi 

🧑‍💻Yaratuvchi $nameuz 

⏳ ".date("Y-m-d H:i:s"),
					        'parse_mode'=>"html",
				        ]);	


				        putfree();
  					} else {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);

				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'text'=>"📛 Noma'lum xatolik",
					        'parse_mode'=>"html"
				        ]);
          			}


				} else {
					bot('sendmessage', [
						'text'=>"📛 Menimcha siz tokenni yuborishda xatolikka yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!", 
						'chat_id'=>$cid, 
						'reply_markup'=>$mainBtn
					]);

				}

				step($fid, '');
			}


			// 4
			if ( file_get_contents('./step/'.$fid.'.txt') == 'freezipbot&token' ) {
				$getMe = json_decode(get("https://api.telegram.org/bot$tx/getMe"));
				$nBot = 'freezipbot';
				if ($getMe->ok == 200) {
					bot('sendmessage', [
						'chat_id'=>$cid,
						'text'=>'Tayyorlanmoqda...'
					]);

				    $kod = file_get_contents("free/$nBot.php");
				    $kod = str_replace("API_TOKEN", "$tx", $kod);
				    $kod = str_replace("ADMIN_ID", "$fid", $kod);
					$kod = str_replace("ADMIN_USER", "$user", $kod);
					mkdir("bots");
					mkdir("bots/$fid");
				    mkdir("bots/$fid/$nBot");
				    if(file_get_contents("bots/$fid/$nBot/$nBot.php")){
				        unlink("bots/$fid/$nBot/strtotime.php");
				        unlink("bots/$fid/$nBot/usid.txt");
				        unlink("bots/$fid/$nBot/grid.txt");
				        $files = glob("bots/$fid/$nBot/baza/*");
				        foreach ($files as $key) {
				        	unlink($key);
				        }
				        rmdir("bots/$fid/$nBot/baza");
				    }
    				file_put_contents("bots/$fid/$nBot/$nBot.php", $kod);
  					$get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/PHP/fayozbek/bots/$fid/$nBot/$nBot.php"))->result;


					$user = $getMe->result->username;
					$nomi = $getMe->result->first_name;
					$idsi = $getMe->result->id;


  					if ($get) {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);


				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'message_id'=>$getid,
					        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Tekin\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $idsi\n\n/panel - admin panel",
					        'parse_mode'=>"html",
					        'reply_markup'=>$mainBtn
				        ]);						



				        bot('sendMessage',[
					        'chat_id'=>$kanal,
					        'text'=>"💡 Diqqat yangi bot yaratildi 💡


💡 Bot turi: Tekin

🤖 Bot nomi $nomi 

🤖 Useri $user 

🗄 Id raqami $idsi 

🧑‍💻Yaratuvchi $nameuz 

⏳ ".date("Y-m-d H:i:s"),
					        'parse_mode'=>"html",
				        ]);	


				        putfree();
  					} else {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);

				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'text'=>"📛 Noma'lum xatolik",
					        'parse_mode'=>"html"
				        ]);
          			}


				} else {
					bot('sendmessage', [
						'text'=>"📛 Menimcha siz tokenni yuborishda xatolikka yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!", 
						'chat_id'=>$cid, 
						'reply_markup'=>$mainBtn
					]);

				}

				step($fid, '');
			}


			// 5
			if ( file_get_contents('./step/'.$fid.'.txt') == 'freejoinbot&token' ) {
				$getMe = json_decode(get("https://api.telegram.org/bot$tx/getMe"));
				$nBot = 'freejoinbot';
				if ($getMe->ok == 200) {
					bot('sendmessage', [
						'chat_id'=>$cid,
						'text'=>'Tayyorlanmoqda...'
					]);

				    $kod = file_get_contents("free/$nBot.php");
				    $kod = str_replace("API_TOKEN", "$tx", $kod);
				    $kod = str_replace("ADMIN_ID", "$fid", $kod);
					$kod = str_replace("ADMIN_USER", "$user", $kod);
					mkdir("bots");
					mkdir("bots/$fid");
				    mkdir("bots/$fid/$nBot");
				    if(file_get_contents("bots/$fid/$nBot/$nBot.php")){
				        unlink("bots/$fid/$nBot/strtotime.php");
				        unlink("bots/$fid/$nBot/usid.txt");
				        unlink("bots/$fid/$nBot/grid.txt");
				        $files = glob("bots/$fid/$nBot/baza/*");
				        foreach ($files as $key) {
				        	unlink($key);
				        }
				        rmdir("bots/$fid/$nBot/baza");
				    }
    				file_put_contents("bots/$fid/$nBot/$nBot.php", $kod);
  					$get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/PHP/fayozbek/bots/$fid/$nBot/$nBot.php"))->result;


					$user = $getMe->result->username;
					$nomi = $getMe->result->first_name;
					$idsi = $getMe->result->id;


  					if ($get) {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);


				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'message_id'=>$getid,
					        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Tekin\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $idsi\n\n/panel - admin panel",
					        'parse_mode'=>"html",
					        'reply_markup'=>$mainBtn
				        ]);						





				        bot('sendMessage',[
					        'chat_id'=>$kanal,
					        'text'=>"💡 Diqqat yangi bot yaratildi 💡


💡 Bot turi: Tekin

🤖 Bot nomi $nomi 

🤖 Useri $user 

🗄 Id raqami $idsi 

🧑‍💻Yaratuvchi $nameuz 

⏳ ".date("Y-m-d H:i:s"),
					        'parse_mode'=>"html",
				        ]);	


				        putfree();
  					} else {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);

				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'text'=>"📛 Noma'lum xatolik",
					        'parse_mode'=>"html"
				        ]);
          			}


				} else {
					bot('sendmessage', [
						'text'=>"📛 Menimcha siz tokenni yuborishda xatolikka yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!", 
						'chat_id'=>$cid, 
						'reply_markup'=>$mainBtn
					]);

				}

				step($fid, '');
			}


			// 6
			if ( file_get_contents('./step/'.$fid.'.txt') == 'freememberbot&token' ) {
				$kanal = explode("\n",$tx)[0];
				$tx = explode("\n",$tx)[1];
				$getMe = json_decode(get("https://api.telegram.org/bot$tx/getMe"));
				$nBot = 'freememberbot';
				if ($getMe->ok == 200) {
					bot('sendmessage', [
						'chat_id'=>$cid,
						'text'=>'Tayyorlanmoqda...'
					]);

				    $kod = file_get_contents("free/$nBot.php");
				    $kod = str_replace("API_TOKEN", "$tx", $kod);
				    $kod = str_replace("ADMIN_ID", "$fid", $kod);
					$kod = str_replace("ADMIN_USER", "$user", $kod);
					$kod = str_replace("KANAL", "$kanal", $kod);
					mkdir("bots");
					mkdir("bots/$fid");
				    mkdir("bots/$fid/$nBot");
				    if(file_get_contents("bots/$fid/$nBot/$nBot.php")){
				        unlink("bots/$fid/$nBot/strtotime.php");
				        unlink("bots/$fid/$nBot/usid.txt");
				        unlink("bots/$fid/$nBot/grid.txt");
				        $files = glob("bots/$fid/$nBot/baza/*");
				        foreach ($files as $key) {
				        	unlink($key);
				        }
				        rmdir("bots/$fid/$nBot/baza");
				    }
    				file_put_contents("bots/$fid/$nBot/$nBot.php", $kod);
  					$get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/PHP/fayozbek/bots/$fid/$nBot/$nBot.php"))->result;


					$user = $getMe->result->username;
					$nomi = $getMe->result->first_name;
					$idsi = $getMe->result->id;


  					if ($get) {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);


				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'message_id'=>$getid,
					        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Tekin\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $idsi\n\n/panel - admin panel \n\nBotni botga bergan kanlingizga admin qilib qoyin, yoqsa bot ishlamaydi !",
					        'parse_mode'=>"html",
					        'reply_markup'=>$mainBtn
				        ]);						




				        bot('sendMessage',[
					        'chat_id'=>$kanal,
					        'text'=>"💡 Diqqat yangi bot yaratildi 💡


💡 Bot turi: Tekin

🤖 Bot nomi $nomi 

🤖 Useri $user 

🗄 Id raqami $idsi 

🧑‍💻Yaratuvchi $nameuz 

⏳ ".date("Y-m-d H:i:s"),
					        'parse_mode'=>"html",
				        ]);	


				        putfree();
  					} else {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);

				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'text'=>"📛 Noma'lum xatolik",
					        'parse_mode'=>"html"
				        ]);
          			}


				} else {
					bot('sendmessage', [
						'text'=>"📛 Menimcha siz tokenni yuborishda xatolikka yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!", 
						'chat_id'=>$cid, 
						'reply_markup'=>$mainBtn
					]);

				}

				step($fid, '');
			}



			// 7
			if ( file_get_contents('./step/'.$fid.'.txt') == 'freekonspectbot&token' ) {
				$getMe = json_decode(get("https://api.telegram.org/bot$tx/getMe"));
				$nBot = 'freekonspectbot';
				if ($getMe->ok == 200) {
					bot('sendmessage', [
						'chat_id'=>$cid,
						'text'=>'Tayyorlanmoqda...'
					]);

				    $kod = file_get_contents("free/$nBot.php");
				    $kod = str_replace("API_TOKEN", "$tx", $kod);
				    $kod = str_replace("ADMIN_ID", "$fid", $kod);
					$kod = str_replace("ADMIN_USER", "$user", $kod);
					mkdir("bots");
					mkdir("bots/$fid");
				    mkdir("bots/$fid/$nBot");
				    if(file_get_contents("bots/$fid/$nBot/$nBot.php")){
				        unlink("bots/$fid/$nBot/strtotime.php");
				        unlink("bots/$fid/$nBot/usid.txt");
				        unlink("bots/$fid/$nBot/grid.txt");
				        $files = glob("bots/$fid/$nBot/baza/*");
				        foreach ($files as $key) {
				        	unlink($key);
				        }
				        rmdir("bots/$fid/$nBot/baza");
				    }
    				file_put_contents("bots/$fid/$nBot/$nBot.php", $kod);
  					$get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/PHP/fayozbek/bots/$fid/$nBot/$nBot.php"))->result;


					$user = $getMe->result->username;
					$nomi = $getMe->result->first_name;
					$idsi = $getMe->result->id;


  					if ($get) {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);


				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'message_id'=>$getid,
					        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Tekin\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $idsi\n\n/panel - admin panel",
					        'parse_mode'=>"html",
					        'reply_markup'=>$mainBtn
				        ]);						




				        bot('sendMessage',[
					        'chat_id'=>$kanal,
					        'text'=>"💡 Diqqat yangi bot yaratildi 💡


💡 Bot turi: Tekin

🤖 Bot nomi $nomi 

🤖 Useri $user 

🗄 Id raqami $idsi 

🧑‍💻Yaratuvchi $nameuz 

⏳ ".date("Y-m-d H:i:s"),
					        'parse_mode'=>"html",
				        ]);	


				        putfree();
  					} else {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);

				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'text'=>"📛 Noma'lum xatolik",
					        'parse_mode'=>"html"
				        ]);
          			}


				} else {
					bot('sendmessage', [
						'text'=>"📛 Menimcha siz tokenni yuborishda xatolikka yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!", 
						'chat_id'=>$cid, 
						'reply_markup'=>$mainBtn
					]);

				}

				step($fid, '');
			} 












// -----------------------------------------------------------------------------------------------------------------------

			# --- END ---------------FAYZLIDEV----------------------  FREE NIK BOT ---------------------------------FAYZLIDEV------------ #










			//  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO 

		if($data == 'money_v3'){
			$get = file_get_contents("coin/$ccid/index.txt");

			if($get < $pullik_narx ){
				    bot('editMessageText',[
				    'message_id'=>$cmid,
				    'chat_id'=>$ccid,
				    'text'=>"💰 Money v0.3 bot yaratish uchun $pullik_narx ta coin kerak. Quyidagi havolani do'stlaringizga tarqatib pul yig'ing:\n<code>https://t.me/$botname?start=$ccid </code>\n\nEslatib o'tamiz har bir do'stingiz sizga <b>$maincoin</b>ta coin beradi\n\nYoki @fayzlidev ga murojaat qilib coin sotib oling!",
				    'parse_mode'=>"html",
				    'disable_web_page_preview'=>true,
				    'reply_markup'=>json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"back"]],
					    ]
				    ])
			    ]);
			}else{
			bot('editMessageText',[
			'message_id'=>$cmid,
		    'chat_id'=>$ccid,
		    'text'=>"1️⃣ @BotFather-ga o'ting.  Botingiz tokenini jo‘nating

		💥Taxminiy API Token:
		 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
		    'reply_markup'=>json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"back"]],
					    ],
				    ])
		    ]);
		    step($ccid,"money_v3&token");
		    }
		}


		if ( $tx and file_get_contents('./step/'.$fid.'.txt') == 'money_v3&token' ) {
				$getMe = json_decode(get("https://api.telegram.org/bot$tx/getMe"));
				$nBot = 'money_v3';
				if ($getMe->ok == 200) {
					bot('sendmessage', [
						'chat_id'=>$cid,
						'text'=>'Tayyorlanmoqda...'
					]);

				    $kod = file_get_contents("money/$nBot.php");
				    $kod = str_replace("API_TOKEN", "$tx", $kod);
				    $kod = str_replace("ADMIN_ID", "$fid", $kod);
					$kod = str_replace("ADMIN_USER", "$user", $kod);
					mkdir("bots");
					mkdir("bots/$fid");
				    mkdir("bots/$fid/$nBot");
				    if(file_get_contents("bots/$fid/$nBot/$nBot.php")){
				        unlink("bots/$fid/$nBot/strtotime.php");
				        unlink("bots/$fid/$nBot/usid.txt");
				        unlink("bots/$fid/$nBot/grid.txt");
				        $files = glob("bots/$fid/$nBot/baza/*");
				        foreach ($files as $key) {
				        	unlink($key);
				        }
				        rmdir("bots/$fid/$nBot/baza");
				    }
    				file_put_contents("bots/$fid/$nBot/$nBot.php", $kod);
  					$get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/PHP/fayozbek/bots/$fid/$nBot/$nBot.php"))->result;


					$user = $getMe->result->username;
					$nomi = $getMe->result->first_name;
					$idsi = $getMe->result->id;


  					if ($get) {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);


				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'message_id'=>$getid,
					        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Pullik\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $idsi\n\n/panel - admin panel",
					        'parse_mode'=>"html",
					        'reply_markup'=>$mainBtn
				        ]);						





				        bot('sendMessage',[
					        'chat_id'=>$kanal,
					        'text'=>"💡 Diqqat yangi bot yaratildi 💡
💡 Bot turi: Pullik		


🤖 Bot nomi $nomi 

🤖 Useri @$user 

🗄 Id raqami $idsi 

🧑‍💻Yaratuvchi $nameuz

⏳ ".date("Y-m-d H:i:s"),
					        'parse_mode'=>"html",
				        ]);	


				        putmoney();
  					} else {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);

				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'text'=>"📛 Noma'lum xatolik",
					        'parse_mode'=>"html"
				        ]);
          			}


				} else {
					bot('sendmessage', [
						'text'=>"📛 Menimcha siz tokenni yuborishda xatolikka yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!", 
						'chat_id'=>$cid, 
						'reply_markup'=>$mainBtn
					]);

				}

				step($fid, '');
			} 


			// 2
			if($data == 'member_v1'){
			$get = file_get_contents("coin/$ccid/index.txt");
			if($get < $pullik_narx ){
				    bot('editMessageText',[
				    'message_id'=>$cmid,
				    'chat_id'=>$ccid,
				    'text'=>"Member v0.1 bot yaratish uchun $pullik_narx ta coin kerak. Quyidagi havolani do'stlaringizga tarqatib pul yig'ing:\n<code>https://t.me/$botname?start=$ccid </code>\n\nEslatib o'tamiz har bir do'stingiz sizga <b>$maincoin</b>ta coin beradi\n\nYoki @fayzlidev ga murojaat qilib coin sotib oling!",
				    'parse_mode'=>"html",
				    'disable_web_page_preview'=>true,
				    'reply_markup'=>json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"back"]],
					    ]
				    ])
			    ]);
			}else{
			bot('sendMessage',[
		    'chat_id'=>$ccid,
		    'text'=>"1️⃣ @BotFather-ga o'ting.  Botingiz tokenini jo‘nating

		💥Taxminiy API Token:
		 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
		    'reply_markup'=>json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"back"]],
					    ]
				    ])
		    ]);
		    step($ccid,"member_v1&token");
		    }
		}


		if ( file_get_contents('./step/'.$fid.'.txt') == 'member_v1&token' ) {
				$getMe = json_decode(get("https://api.telegram.org/bot$tx/getMe"));
				$nBot = 'member_v1';
				if ($getMe->ok == 200) {
					bot('sendmessage', [
						'chat_id'=>$cid,
						'text'=>'Tayyorlanmoqda...'
					]);

				    $kod = file_get_contents("money/$nBot.php");
				    $kod = str_replace("API_TOKEN", "$tx", $kod);
				    $kod = str_replace("ADMIN_ID", "$fid", $kod);
					$kod = str_replace("ADMIN_USER", "$user", $kod);
					mkdir("bots");
					mkdir("bots/$fid");
				    mkdir("bots/$fid/$nBot");
				    if(file_get_contents("bots/$fid/$nBot/$nBot.php")){
				        unlink("bots/$fid/$nBot/strtotime.php");
				        unlink("bots/$fid/$nBot/usid.txt");
				        unlink("bots/$fid/$nBot/grid.txt");
				        $files = glob("bots/$fid/$nBot/baza/*");
				        foreach ($files as $key) {
				        	unlink($key);
				        }
				        rmdir("bots/$fid/$nBot/baza");
				    }
    				file_put_contents("bots/$fid/$nBot/$nBot.php", $kod);
  					$get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/PHP/fayozbek/bots/$fid/$nBot/$nBot.php"))->result;


					$user = $getMe->result->username;
					$nomi = $getMe->result->first_name;
					$idsi = $getMe->result->id;


  					if ($get) {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);


				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'message_id'=>$getid,
					        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Pullik\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $idsi\n\n/panel - admin panel",
					        'parse_mode'=>"html",
					        'reply_markup'=>$mainBtn
				        ]);	


						$ayrish = file_get_contents('coin/'.$cid.'/index.txt') - $pullik_narx;
				        file_put_contents('coin/'.$cid.'/index.txt', $ayrish);


				        bot('sendMessage',[
					        'chat_id'=>$kanal,
					        'text'=>"💡 Diqqat yangi bot yaratildi 💡
💡 Bot turi: Pullik					        
🤖 Bot nomi $nomi  
🤖 Useri $user 
🗄 Id raqami $idsi 
🧑‍💻Yaratuvchi $nameuz 
⏳ ".date("Y-m-d H:i:s"),
					        'parse_mode'=>"html",
					        'reply_markup'=>$mainBtn
				        ]);	


				        putmoney();					
  					} else {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);

				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'text'=>"📛	 Noma'lum xatolik",
					        'parse_mode'=>"html"
				        ]);
          			}


				} else {
					bot('sendmessage', [
						'text'=>"📛 Menimcha siz tokenni yuborishda xatolikka yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!", 
						'chat_id'=>$cid, 
						'reply_markup'=>$mainBtn
					]);

				}

				step($fid, '');
			}

			// 3
			if($data == 'rubl_v1'){
			$get = file_get_contents("coin/$ccid/index.txt");
			if($get < $pullik_narx ){
				    bot('editMessageText',[
				    'message_id'=>$cmid,
				    'chat_id'=>$ccid,
				    'text'=>"Rubl v0.1  bot yaratish uchun $pullik_narx ta coin kerak. Quyidagi havolani do'stlaringizga tarqatib pul yig'ing:\n<code>https://t.me/$botname?start=$ccid </code>\n\nEslatib o'tamiz har bir do'stingiz sizga <b>$maincoin</b>ta coin beradi\n\nYoki @fayzlidev ga murojaat qilib coin sotib oling!",
				    'parse_mode'=>"html",
				    'disable_web_page_preview'=>true,
				    'reply_markup'=>json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"back"]],
					    ]
				    ])
			    ]);
			}else{
			bot('sendMessage',[
		    'chat_id'=>$ccid,
		    'text'=>"1️⃣ @BotFather-ga o'ting.  Botingiz tokenini jo‘nating

		💥Taxminiy API Token:
		 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
		    'reply_markup'=>json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"back"]],
					    ]
				    ])
		    ]);
		    step($ccid,"rubl_v1&token");
		    }
		}


		if ( file_get_contents('./step/'.$fid.'.txt') == 'rubl_v1&token' ) {
				$getMe = json_decode(get("https://api.telegram.org/bot$tx/getMe"));
				$nBot = 'rubl_v1';
				if ($getMe->ok == 200) {
					bot('sendmessage', [
						'chat_id'=>$cid,
						'text'=>'Tayyorlanmoqda...'
					]);

				    $kod = file_get_contents("money/$nBot.php");
				    $kod = str_replace("API_TOKEN", "$tx", $kod);
				    $kod = str_replace("ADMIN_ID", "$fid", $kod);
					$kod = str_replace("ADMIN_USER", "$user", $kod);
					mkdir("bots");
					mkdir("bots/$fid");
				    mkdir("bots/$fid/$nBot");
				    if(file_get_contents("bots/$fid/$nBot/$nBot.php")){
				        unlink("bots/$fid/$nBot/strtotime.php");
				        unlink("bots/$fid/$nBot/usid.txt");
				        unlink("bots/$fid/$nBot/grid.txt");
				        $files = glob("bots/$fid/$nBot/baza/*");
				        foreach ($files as $key) {
				        	unlink($key);
				        }
				        rmdir("bots/$fid/$nBot/baza");
				    }
    				file_put_contents("bots/$fid/$nBot/$nBot.php", $kod);
  					$get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/PHP/fayozbek/bots/$fid/$nBot/$nBot.php"))->result;


					$user = $getMe->result->username;
					$nomi = $getMe->result->first_name;
					$idsi = $getMe->result->id;


  					if ($get) {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);


				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'message_id'=>$getid,
					        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Pullik\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $idsi\n\n/panel - admin panel",
					        'parse_mode'=>"html",
					        'reply_markup'=>$mainBtn
				        ]);	


						$ayrish = file_get_contents('coin/'.$cid.'/index.txt') - $pullik_narx;
				        file_put_contents('coin/'.$cid.'/index.txt', $ayrish);


				        bot('sendMessage',[
					        'chat_id'=>$kanal,
					        'text'=>"💡 Diqqat yangi bot yaratildi 💡
💡 Bot turi: Pullik		


🤖 Bot nomi $nomi 

🤖 Useri @$user 

🗄 Id raqami $idsi 

🧑‍💻Yaratuvchi $nameuz

⏳ ".date("Y-m-d H:i:s"),
					        'parse_mode'=>"html",
				        ]);	


				        putmoney();					
  					} else {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);

				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'text'=>"📛 Noma'lum xatolik",
					        'parse_mode'=>"html"
				        ]);
          			}


				} else {
					bot('sendmessage', [
						'text'=>"📛 Menimcha siz tokenni yuborishda xatolikka yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!", 
						'chat_id'=>$cid, 
						'reply_markup'=>$mainBtn
					]);

				}

				step($fid, '');
			}

			// 4
			if($data == 'member_v2'){
			$get = file_get_contents("coin/$ccid/index.txt");
			if($get < $pullik_narx ){
				    bot('editMessageText',[
				    'message_id'=>$cmid,
				    'chat_id'=>$ccid,
				    'text'=>"Member v0.2 bot yaratish uchun $pullik_narx ta coin kerak. Quyidagi havolani do'stlaringizga tarqatib pul yig'ing:\n<code>https://t.me/$botname?start=$ccid </code>\n\nEslatib o'tamiz har bir do'stingiz sizga <b>$maincoin</b>ta coin beradi\n\nYoki @fayzlidev ga murojaat qilib coin sotib oling!",
				    'parse_mode'=>"html",
				    'disable_web_page_preview'=>true,
				    'reply_markup'=>json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"back"]],
					    ]
				    ])
			    ]);
			}else{
			bot('sendMessage',[
		    'chat_id'=>$ccid,
		    'text'=>"1️⃣ @BotFather-ga o'ting.  Botingiz tokenini jo‘nating

		💥Taxminiy API Token:
		 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
		    'reply_markup'=>json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"back"]],
					    ]
				    ])
		    ]);
		    step($ccid,"member_v2&token");
		    }
		}


		if ( file_get_contents('./step/'.$fid.'.txt') == 'member_v2&token' ) {
				$getMe = json_decode(get("https://api.telegram.org/bot$tx/getMe"));
				$nBot = 'member_v2';
				if ($getMe->ok == 200) {
					bot('sendmessage', [
						'chat_id'=>$cid,
						'text'=>'Tayyorlanmoqda...'
					]);

				    $kod = file_get_contents("money/$nBot.php");
				    $kod = str_replace("API_TOKEN", "$tx", $kod);
				    $kod = str_replace("ADMIN_ID", "$fid", $kod);
					$kod = str_replace("ADMIN_USER", "$user", $kod);
					mkdir("bots");
					mkdir("bots/$fid");
				    mkdir("bots/$fid/$nBot");
				    if(file_get_contents("bots/$fid/$nBot/$nBot.php")){
				        unlink("bots/$fid/$nBot/strtotime.php");
				        unlink("bots/$fid/$nBot/usid.txt");
				        unlink("bots/$fid/$nBot/grid.txt");
				        $files = glob("bots/$fid/$nBot/baza/*");
				        foreach ($files as $key) {
				        	unlink($key);
				        }
				        rmdir("bots/$fid/$nBot/baza");
				    }
    				file_put_contents("bots/$fid/$nBot/$nBot.php", $kod);
  					$get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/PHP/fayozbek/bots/$fid/$nBot/$nBot.php"))->result;


					$user = $getMe->result->username;
					$nomi = $getMe->result->first_name;
					$idsi = $getMe->result->id;


  					if ($get) {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);


				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'message_id'=>$getid,
					        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Pullik\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $idsi\n\n/panel - admin panel",
					        'parse_mode'=>"html",
					        'reply_markup'=>$mainBtn
				        ]);	


						$ayrish = file_get_contents('coin/'.$cid.'/index.txt') - $pullik_narx;
				        file_put_contents('coin/'.$cid.'/index.txt', $ayrish);


				        bot('sendMessage',[
					        'chat_id'=>$kanal,
					        'text'=>"💡 Diqqat yangi bot yaratildi 💡
💡 Bot turi: Pullik		


🤖 Bot nomi $nomi 

🤖 Useri @$user 

🗄 Id raqami $idsi 

🧑‍💻Yaratuvchi $nameuz

⏳ ".date("Y-m-d H:i:s"),
					        'parse_mode'=>"html",
				        ]);	


				        putmoney();					
  					} else {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);

				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'text'=>"📛 Noma'lum xatolik",
					        'parse_mode'=>"html"
				        ]);
          			}


				} else {
					bot('sendmessage', [
						'text'=>"📛 Menimcha siz tokenni yuborishda xatolikka yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!", 
						'chat_id'=>$cid, 
						'reply_markup'=>$mainBtn
					]);

				}

				step($fid, '');
			}








			//  +++++++++++++++ 44444444444444444444444444444 ++++++++++++++
			if($data == 'oxranbot'){
			$get = file_get_contents("coin/$ccid/index.txt");
			if($get < $pullik_narx ){
				    bot('editMessageText',[
				    'message_id'=>$cmid,
				    'chat_id'=>$ccid,
				    'text'=>"Oxrana bot yaratish uchun $pullik_narx ta coin kerak. Quyidagi havolani do'stlaringizga tarqatib pul yig'ing:\n<code>https://t.me/$botname?start=$ccid </code>\n\nEslatib o'tamiz har bir do'stingiz sizga <b>$maincoin</b>ta coin beradi\n\nYoki @fayzlidev ga murojaat qilib coin sotib oling!",
				    'parse_mode'=>"html",
				    'disable_web_page_preview'=>true,
				    'reply_markup'=>json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"back"]],
					    ]
				    ])
			    ]);
			}else{
			bot('sendMessage',[
		    'chat_id'=>$ccid,
		    'text'=>"1️⃣ @BotFather-ga o'ting.  Botingiz tokenini jo‘nating

		💥Taxminiy API Token:
		 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
		    'reply_markup'=>json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"back"]],
					    ]
				    ])
		    ]);
		    step($ccid,"oxranbot&token");
		    }
		}


		if ( file_get_contents('./step/'.$fid.'.txt') == 'oxranbot&token' ) {
				$getMe = json_decode(get("https://api.telegram.org/bot$tx/getMe"));
				$nBot = 'oxranbot';
				if ($getMe->ok == 200) {
					bot('sendmessage', [
						'chat_id'=>$cid,
						'text'=>'Tayyorlanmoqda...'
					]);

				    $kod = file_get_contents("money/$nBot.php");
				    $kod = str_replace("API_TOKEN", "$tx", $kod);
				    $kod = str_replace("ADMIN_ID", "$fid", $kod);
					$kod = str_replace("ADMIN_USER", "$user", $kod);
					mkdir("bots");
					mkdir("bots/$fid");
				    mkdir("bots/$fid/$nBot");
				    if(file_get_contents("bots/$fid/$nBot/$nBot.php")){
				        unlink("bots/$fid/$nBot/strtotime.php");
				        unlink("bots/$fid/$nBot/usid.txt");
				        unlink("bots/$fid/$nBot/grid.txt");
				        $files = glob("bots/$fid/$nBot/baza/*");
				        foreach ($files as $key) {
				        	unlink($key);
				        }
				        rmdir("bots/$fid/$nBot/baza");
				    }
    				file_put_contents("bots/$fid/$nBot/$nBot.php", $kod);
  					$get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/PHP/fayozbek/bots/$fid/$nBot/$nBot.php"))->result;


					$user = $getMe->result->username;
					$nomi = $getMe->result->first_name;
					$idsi = $getMe->result->id;


  					if ($get) {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);


				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'message_id'=>$getid,
					        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Pullik\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $idsi\n\n/panel - admin panel",
					        'parse_mode'=>"html",
					        'reply_markup'=>$mainBtn
				        ]);	


						$ayrish = file_get_contents('coin/'.$cid.'/index.txt') - $pullik_narx;
				        file_put_contents('coin/'.$cid.'/index.txt', $ayrish);


				        bot('sendMessage',[
					        'chat_id'=>$kanal,
					        'text'=>"💡 Diqqat yangi bot yaratildi 💡
💡 Bot turi: Pullik		


🤖 Bot nomi $nomi 

🤖 Useri @$user 

🗄 Id raqami $idsi 

🧑‍💻Yaratuvchi $nameuz

⏳ ".date("Y-m-d H:i:s"),
					        'parse_mode'=>"html",
				        ]);	


				        putmoney();					
  					} else {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);

				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'text'=>"📛 Noma'lum xatolik",
					        'parse_mode'=>"html"
				        ]);
          			}


				} else {
					bot('sendmessage', [
						'text'=>"📛 Menimcha siz tokenni yuborishda xatolikka yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!", 
						'chat_id'=>$cid, 
						'reply_markup'=>$mainBtn
					]);

				}

				step($fid, '');
			} 


			// 2
			if($data == 'rubl_v2'){
			$get = file_get_contents("coin/$ccid/index.txt");
			if($get < $pullik_narx ){
				    bot('editMessageText',[
				    'message_id'=>$cmid,
				    'chat_id'=>$ccid,
				    'text'=>"Rubl v0.2 bot yaratish uchun $pullik_narx ta coin kerak. Quyidagi havolani do'stlaringizga tarqatib pul yig'ing:\n<code>https://t.me/$botname?start=$ccid </code>\n\nEslatib o'tamiz har bir do'stingiz sizga <b>$maincoin</b>ta coin beradi\n\nYoki @fayzlidev ga murojaat qilib coin sotib oling!",
				    'parse_mode'=>"html",
				    'disable_web_page_preview'=>true,
				    'reply_markup'=>json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"back"]],
					    ]
				    ])
			    ]);
			}else{
			bot('sendMessage',[
		    'chat_id'=>$ccid,
		    'text'=>"1️⃣ @BotFather-ga o'ting.  Botingiz tokenini jo‘nating

		💥Taxminiy API Token:
		 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
		    'reply_markup'=>json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"back"]],
					    ]
				    ])
		    ]);
		    step($ccid,"rubl_v2&token");
		    }
		}


		if ( file_get_contents('./step/'.$fid.'.txt') == 'rubl_v2&token' ) {
				$getMe = json_decode(get("https://api.telegram.org/bot$tx/getMe"));
				$nBot = 'rubl_v2';
				if ($getMe->ok == 200) {
					bot('sendmessage', [
						'chat_id'=>$cid,
						'text'=>'Tayyorlanmoqda...'
					]);

				    $kod = file_get_contents("money/$nBot.php");
				    $kod = str_replace("API_TOKEN", "$tx", $kod);
				    $kod = str_replace("ADMIN_ID", "$fid", $kod);
					$kod = str_replace("ADMIN_USER", "$user", $kod);
					mkdir("bots");
					mkdir("bots/$fid");
				    mkdir("bots/$fid/$nBot");
				    if(file_get_contents("bots/$fid/$nBot/$nBot.php")){
				        unlink("bots/$fid/$nBot/strtotime.php");
				        unlink("bots/$fid/$nBot/usid.txt");
				        unlink("bots/$fid/$nBot/grid.txt");
				        $files = glob("bots/$fid/$nBot/baza/*");
				        foreach ($files as $key) {
				        	unlink($key);
				        }
				        rmdir("bots/$fid/$nBot/baza");
				    }
    				file_put_contents("bots/$fid/$nBot/$nBot.php", $kod);
  					$get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/PHP/fayozbek/bots/$fid/$nBot/$nBot.php"))->result;


					$user = $getMe->result->username;
					$nomi = $getMe->result->first_name;
					$idsi = $getMe->result->id;


  					if ($get) {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);


				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'message_id'=>$getid,
					        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Pullik\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $idsi\n\n/panel - admin panel",
					        'parse_mode'=>"html",
					        'reply_markup'=>$mainBtn
				        ]);		


						$ayrish = file_get_contents('coin/'.$cid.'/index.txt') - $pullik_narx;
				        file_put_contents('coin/'.$cid.'/index.txt', $ayrish);



				        bot('sendMessage',[
					        'chat_id'=>$kanal,
					        'text'=>"💡 Diqqat yangi bot yaratildi 💡
💡 Bot turi: Pullik		


🤖 Bot nomi $nomi 

🤖 Useri @$user 

🗄 Id raqami $idsi 

🧑‍💻Yaratuvchi $nameuz

⏳ ".date("Y-m-d H:i:s"),
					        'parse_mode'=>"html",
				        ]);	


				        putmoney();				
  					} else {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);

				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'text'=>"📛 Noma'lum xatolik",
					        'parse_mode'=>"html"
				        ]);
          			}


				} else {
					bot('sendmessage', [
						'text'=>"📛 Menimcha siz tokenni yuborishda xatolikka yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!", 
						'chat_id'=>$cid, 
						'reply_markup'=>$mainBtn
					]);

				}

				step($fid, '');
			}

			// 3
			if($data == 'member_v3'){
			$get = file_get_contents("coin/$ccid/index.txt");
			if($get < $pullik_narx ){
				    bot('editMessageText',[
				    'message_id'=>$cmid,
				    'chat_id'=>$ccid,
				    'text'=>"Member v0.3 bot yaratish uchun $pullik_narx ta coin kerak. Quyidagi havolani do'stlaringizga tarqatib pul yig'ing:\n<code>https://t.me/$botname?start=$ccid </code>\n\nEslatib o'tamiz har bir do'stingiz sizga <b>$maincoin</b>ta coin beradi\n\nYoki @fayzlidev ga murojaat qilib coin sotib oling!",
				    'parse_mode'=>"html",
				    'disable_web_page_preview'=>true,
				    'reply_markup'=>json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"back"]],
					    ]
				    ])
			    ]);
			}else{
			bot('sendMessage',[
		    'chat_id'=>$ccid,
		    'text'=>"1️⃣ @BotFather-ga o'ting.  Botingiz tokenini jo‘nating

		💥Taxminiy API Token:
		 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
		    'reply_markup'=>json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"back"]],
					    ]
				    ])
		    ]);
		    step($ccid,"member_v3&token");
		    }
		}


		if ( file_get_contents('./step/'.$fid.'.txt') == 'member_v3&token' ) {
				$getMe = json_decode(get("https://api.telegram.org/bot$tx/getMe"));
				$nBot = 'member_v3';
				if ($getMe->ok == 200) {
					bot('sendmessage', [
						'chat_id'=>$cid,
						'text'=>'Tayyorlanmoqda...'
					]);

				    $kod = file_get_contents("money/$nBot.php");
				    $kod = str_replace("API_TOKEN", "$tx", $kod);
				    $kod = str_replace("ADMIN_ID", "$fid", $kod);
					$kod = str_replace("ADMIN_USER", "$user", $kod);
					mkdir("bots");
					mkdir("bots/$fid");
				    mkdir("bots/$fid/$nBot");
				    if(file_get_contents("bots/$fid/$nBot/$nBot.php")){
				        unlink("bots/$fid/$nBot/strtotime.php");
				        unlink("bots/$fid/$nBot/usid.txt");
				        unlink("bots/$fid/$nBot/grid.txt");
				        $files = glob("bots/$fid/$nBot/baza/*");
				        foreach ($files as $key) {
				        	unlink($key);
				        }
				        rmdir("bots/$fid/$nBot/baza");
				    }
    				file_put_contents("bots/$fid/$nBot/$nBot.php", $kod);
  					$get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/PHP/fayozbek/bots/$fid/$nBot/$nBot.php"))->result;


					$user = $getMe->result->username;
					$nomi = $getMe->result->first_name;
					$idsi = $getMe->result->id;


  					if ($get) {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);


				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'message_id'=>$getid,
					        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Pullik\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $idsi\n\n/panel - admin panel",
					        'parse_mode'=>"html",
					        'reply_markup'=>$mainBtn
				        ]);			

				        $ayrish = file_get_contents('coin/'.$cid.'/index.txt') - $pullik_narx;
				        file_put_contents('coin/'.$cid.'/index.txt', $ayrish);



				        bot('sendMessage',[
					        'chat_id'=>$kanal,
					        'text'=>"💡 Diqqat yangi bot yaratildi 💡

💡 Bot turi: Pullik		


🤖 Bot nomi $nomi 

🤖 Useri @$user 

🗄 Id raqami $idsi 

🧑‍💻Yaratuvchi $nameuz

⏳ ".date("Y-m-d H:i:s"),
					        'parse_mode'=>"html",
				        ]);	


				        putmoney();			
  					} else {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);

				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'text'=>"📛 Noma'lum xatolik",
					        'parse_mode'=>"html"
				        ]);
          			}


				} else {
					bot('sendmessage', [
						'text'=>"📛 Menimcha siz tokenni yuborishda xatolikka yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!", 
						'chat_id'=>$cid, 
						'reply_markup'=>$mainBtn
					]);

				}

				step($fid, '');
			}

			// 4
			if($data == 'logobot'){
			$get = file_get_contents("coin/$ccid/index.txt");
			if($get < $pro_narx ){
				    bot('editMessageText',[
				    'message_id'=>$cmid,
				    'chat_id'=>$ccid,
				    'text'=>"Logo bot yaratish uchun $pro_narx ta coin kerak. Quyidagi havolani do'stlaringizga tarqatib pul yig'ing:\n<code>https://t.me/$botname?start=$ccid </code>\n\nEslatib o'tamiz har bir do'stingiz sizga <b>$maincoin</b>ta coin beradi\n\nYoki @fayzlidev ga murojaat qilib coin sotib oling!",
				    'parse_mode'=>"html",
				    'disable_web_page_preview'=>true,
				    'reply_markup'=>json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"back"]],
					    ]
				    ])
			    ]);
			}else{
			bot('sendMessage',[
		    'chat_id'=>$ccid,
		    'text'=>"1️⃣ @BotFather-ga o'ting.  Botingiz tokenini jo‘nating

		💥Taxminiy API Token:
		 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
		    'reply_markup'=>json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"back"]],
					    ]
				    ])
		    ]);
		    step($ccid,"logobot&token");
		    }
		}


		if ( file_get_contents('./step/'.$fid.'.txt') == 'logobot&token' ) {
				$getMe = json_decode(get("https://api.telegram.org/bot$tx/getMe"));
				$nBot = 'logobot';
				if ($getMe->ok == 200) {
					bot('sendmessage', [
						'chat_id'=>$cid,
						'text'=>'Tayyorlanmoqda...'
					]);

				    $kod = file_get_contents("pro/$nBot.php");
				    $kod = str_replace("API_TOKEN", "$tx", $kod);
				    $kod = str_replace("ADMIN_ID", "$fid", $kod);
					$kod = str_replace("ADMIN_USER", "$user", $kod);
					mkdir("bots");
					mkdir("bots/$fid");
				    mkdir("bots/$fid/$nBot");
				    if(file_get_contents("bots/$fid/$nBot/$nBot.php")){
				        unlink("bots/$fid/$nBot/strtotime.php");
				        unlink("bots/$fid/$nBot/usid.txt");
				        unlink("bots/$fid/$nBot/grid.txt");
				        $files = glob("bots/$fid/$nBot/baza/*");
				        foreach ($files as $key) {
				        	unlink($key);
				        }
				        rmdir("bots/$fid/$nBot/baza");
				    }
    				file_put_contents("bots/$fid/$nBot/$nBot.php", $kod);
  					$get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/PHP/fayozbek/bots/$fid/$nBot/$nBot.php"))->result;


					$user = $getMe->result->username;
					$nomi = $getMe->result->first_name;
					$idsi = $getMe->result->id;


  					if ($get) {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);


				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'message_id'=>$getid,
					        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: PRO\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $idsi\n\n/panel - admin panel",
					        'parse_mode'=>"html",
					        'reply_markup'=>$mainBtn
				        ]);		



				        bot('sendMessage',[
					        'chat_id'=>$kanal,
					        'text'=>"💡 Diqqat yangi pro bot yaratildi 💡


💡 Bot turi: Pro				

🤖 Bot nomi $nomi  

🤖 Useri $user 

🗄 Id raqami $idsi 

🧑‍💻Yaratuvchi $nameuz 

⏳ ".date("Y-m-d H:i:s"),
					        
					        'parse_mode'=>"html",
				        ]);	


				        putpro();				
  					} else {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);

				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'text'=>"📛 Noma'lum xatolik",
					        'parse_mode'=>"html"
				        ]);
          			}


				} else {
					bot('sendmessage', [
						'text'=>"📛 Menimcha siz tokenni yuborishda xatolikka yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!", 
						'chat_id'=>$cid, 
						'reply_markup'=>$mainBtn
					]);

				}

				step($fid, '');
			}



			//  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO  PRO 

// 111111111111111111111111111111111111111111111111111111111
			if($data == 'avtonakbot'){
			$get = file_get_contents("coin/$ccid/index.txt");
			if($get < $pro_narx ){
				    bot('editMessageText',[
				    'message_id'=>$cmid,
				    'chat_id'=>$ccid,
				    'text'=>"❄AvtoNakrutka bot yaratish uchun $pro_narx ta ☣️ coin kerak. Quyidagi havolani do'stlaringizga tarqatib pul yig'ing:\n<code>https://t.me/$botname?start=$ccid </code>\n\nEslatib o'tamiz har bir do'stingiz sizga <b>$maincoin</b>ta coin beradi\n\nYoki @fayzlidev ga murojaat qilib coin sotib oling!",
				    'parse_mode'=>"html",
				    'disable_web_page_preview'=>true,
				    'reply_markup'=>json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"back"]],
					    ]
				    ])
			    ]);
			}else{
			bot('sendMessage',[
		    'chat_id'=>$ccid,
		    'text'=>"1️⃣ @BotFather-ga o'ting.  Botingiz tokenini jo‘nating

		💥Taxminiy API Token:
		 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
		    'reply_markup'=>json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"back"]],
					    ]
				    ])
		    ]);
		    step($ccid,"avtonakbot&token");
		    }
		}


		if ( file_get_contents('./step/'.$fid.'.txt') == 'avtonakbot&token' ) {
				$getMe = json_decode(get("https://api.telegram.org/bot$tx/getMe"));
				$nBot = 'avtonakbot';
				if ($getMe->ok == 200) {
					bot('sendmessage', [
						'chat_id'=>$cid,
						'text'=>'Tayyorlanmoqda...'
					]);

				    $kod = file_get_contents("pro/$nBot.php");
				    $kod = str_replace("API_TOKEN", "$tx", $kod);
				    $kod = str_replace("ADMIN_ID", "$fid", $kod);
					$kod = str_replace("ADMIN_USER", "$user", $kod);
					mkdir("bots");
					mkdir("bots/$fid");
				    mkdir("bots/$fid/$nBot");
				    if(file_get_contents("bots/$fid/$nBot/$nBot.php")){
				        unlink("bots/$fid/$nBot/strtotime.php");
				        unlink("bots/$fid/$nBot/usid.txt");
				        unlink("bots/$fid/$nBot/grid.txt");
				        $files = glob("bots/$fid/$nBot/baza/*");
				        foreach ($files as $key) {
				        	unlink($key);
				        }
				        rmdir("bots/$fid/$nBot/baza");
				    }
    				file_put_contents("bots/$fid/$nBot/$nBot.php", $kod);
  					$get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/PHP/fayozbek/bots/$fid/$nBot/$nBot.php"))->result;


					$user = $getMe->result->username;
					$nomi = $getMe->result->first_name;
					$idsi = $getMe->result->id;


  					if ($get) {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);


				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'message_id'=>$getid,
					        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: PRO\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $idsi\n\n/panel - admin panel",
					        'parse_mode'=>"html",
					        'reply_markup'=>$mainBtn
				        ]);		


				        bot('sendMessage',[
					        'chat_id'=>$kanal,
					        'text'=>"💡 Diqqat yangi pro bot yaratildi 💡


💡 Bot turi: Pro				

🤖 Bot nomi $nomi  

🤖 Useri $user 

🗄 Id raqami $idsi 

🧑‍💻Yaratuvchi $nameuz 

⏳ ".date("Y-m-d H:i:s"),
					        'parse_mode'=>"html",
				        ]);	


				        putpro();				
  					} else {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);

				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'text'=>"📛 Noma'lum xatolik",
					        'parse_mode'=>"html"
				        ]);
          			}


				} else {
					bot('sendmessage', [
						'text'=>"📛 Menimcha siz tokenni yuborishda xatolikka yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!", 
						'chat_id'=>$cid, 
						'reply_markup'=>$mainBtn
					]);

				}

				step($fid, '');
			}






			if($data == 'namemeanbot'){
			$get = file_get_contents("coin/$ccid/index.txt");
			if($get < $pro_narx ){
				    bot('editMessageText',[
				    'message_id'=>$cmid,
				    'chat_id'=>$ccid,
				    'text'=>"📚Ismlar manosi botini yaratish uchun $pro_narx ta ☣️ coin kerak. Quyidagi havolani do'stlaringizga tarqatib pul yig'ing:\n<code>https://t.me/$botname?start=$ccid </code>\n\nEslatib o'tamiz har bir do'stingiz sizga <b>$maincoin</b>ta coin beradi\n\nYoki @fayzlidev ga murojaat qilib coin sotib oling!",
				    'parse_mode'=>"html",
				    'disable_web_page_preview'=>true,
				    'reply_markup'=>json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"back"]],
					    ]
				    ])
			    ]);
			}else{
			bot('sendMessage',[
		    'chat_id'=>$ccid,
		    'text'=>"1️⃣ @BotFather-ga o'ting.  Botingiz tokenini jo‘nating

		💥Taxminiy API Token:
		 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
		    'reply_markup'=>json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"back"]],
					    ]
				    ])
		    ]);
		    step($ccid,"namemeanbot&token");
		    }
		}


		if ( file_get_contents('./step/'.$fid.'.txt') == 'namemeanbot&token' ) {
				$getMe = json_decode(get("https://api.telegram.org/bot$tx/getMe"));
				$nBot = 'namemeanbot';
				if ($getMe->ok == 200) {
					bot('sendmessage', [
						'chat_id'=>$cid,
						'text'=>'Tayyorlanmoqda...'
					]);

				    $kod = file_get_contents("pro/$nBot.php");
				    $kod = str_replace("API_TOKEN", "$tx", $kod);
				    $kod = str_replace("ADMIN_ID", "$fid", $kod);
					$kod = str_replace("ADMIN_USER", "$user", $kod);
					mkdir("bots");
					mkdir("bots/$fid");
				    mkdir("bots/$fid/$nBot");
				    if(file_get_contents("bots/$fid/$nBot/$nBot.php")){
				        unlink("bots/$fid/$nBot/strtotime.php");
				        unlink("bots/$fid/$nBot/usid.txt");
				        unlink("bots/$fid/$nBot/grid.txt");
				        $files = glob("bots/$fid/$nBot/baza/*");
				        foreach ($files as $key) {
				        	unlink($key);
				        }
				        rmdir("bots/$fid/$nBot/baza");
				    }
    				file_put_contents("bots/$fid/$nBot/$nBot.php", $kod);
  					$get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/PHP/fayozbek/bots/$fid/$nBot/$nBot.php"))->result;


					$user = $getMe->result->username;
					$nomi = $getMe->result->first_name;
					$idsi = $getMe->result->id;


  					if ($get) {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);


				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'message_id'=>$getid,
					        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: PRO\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $idsi\n\n/panel - admin panel",
					        'parse_mode'=>"html",
					        'reply_markup'=>$mainBtn
				        ]);		


				        bot('sendMessage',[
					        'chat_id'=>$kanal,
					        'text'=>"💡 Diqqat yangi pro bot yaratildi 💡


💡 Bot turi: Pro				

🤖 Bot nomi $nomi  

🤖 Useri $user 

🗄 Id raqami $idsi 

🧑‍💻Yaratuvchi $nameuz 

⏳ ".date("Y-m-d H:i:s"),
					        'parse_mode'=>"html",
				        ]);	


				        putpro();				
  					} else {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);

				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'text'=>"📛 Noma'lum xatolik",
					        'parse_mode'=>"html"
				        ]);
          			}


				} else {
					bot('sendmessage', [
						'text'=>"📛 Menimcha siz tokenni yuborishda xatolikka yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!", 
						'chat_id'=>$cid, 
						'reply_markup'=>$mainBtn
					]);

				}

				step($fid, '');
			}





			if($data == 'rublbot'){
			$get = file_get_contents("coin/$ccid/index.txt");
			if($get < $pro_narx ){
				    bot('editMessageText',[
				    'message_id'=>$cmid,
				    'chat_id'=>$ccid,
				    'text'=>"Rubl bot yaratish uchun $pro_narx ta ☣️ coin kerak. Quyidagi havolani do'stlaringizga tarqatib pul yig'ing:\n<code>https://t.me/$botname?start=$ccid </code>\n\nEslatib o'tamiz har bir do'stingiz sizga <b>$maincoin</b>ta coin beradi\n\nYoki @fayzlidev ga murojaat qilib coin sotib oling!",
				    'parse_mode'=>"html",
				    'disable_web_page_preview'=>true,
				    'reply_markup'=>json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"back"]],
					    ]
				    ])
			    ]);
			}else{
			bot('sendMessage',[
		    'chat_id'=>$ccid,
		    'text'=>"1️⃣ @BotFather-ga o'ting.  Botingiz tokenini jo‘nating

		💥Taxminiy API Token:
		 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
		    'reply_markup'=>json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"back"]],
					    ]
				    ])
		    ]);
		    step($ccid,"rublbot&token");
		    }
		}


		if ( file_get_contents('./step/'.$fid.'.txt') == 'rublbot&token' ) {
				$getMe = json_decode(get("https://api.telegram.org/bot$tx/getMe"));
				$nBot = 'rublbot';
				if ($getMe->ok == 200) {
					bot('sendmessage', [
						'chat_id'=>$cid,
						'text'=>'Tayyorlanmoqda...'
					]);

				    $kod = file_get_contents("pro/$nBot.php");
				    $kod = str_replace("API_TOKEN", "$tx", $kod);
				    $kod = str_replace("ADMIN_ID", "$fid", $kod);
					$kod = str_replace("ADMIN_USER", "$user", $kod);
					mkdir("bots");
					mkdir("bots/$fid");
				    mkdir("bots/$fid/$nBot");
				    if(file_get_contents("bots/$fid/$nBot/$nBot.php")){
				        unlink("bots/$fid/$nBot/strtotime.php");
				        unlink("bots/$fid/$nBot/usid.txt");
				        unlink("bots/$fid/$nBot/grid.txt");
				        $files = glob("bots/$fid/$nBot/baza/*");
				        foreach ($files as $key) {
				        	unlink($key);
				        }
				        rmdir("bots/$fid/$nBot/baza");
				    }
    				file_put_contents("bots/$fid/$nBot/$nBot.php", $kod);
  					$get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/PHP/fayozbek/bots/$fid/$nBot/$nBot.php"))->result;


					$user = $getMe->result->username;
					$nomi = $getMe->result->first_name;
					$idsi = $getMe->result->id;


  					if ($get) {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);


				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'message_id'=>$getid,
					        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: PRO\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $idsi\n\n/panel - admin panel",
					        'parse_mode'=>"html",
					        'reply_markup'=>$mainBtn
				        ]);	


				        bot('sendMessage',[
					        'chat_id'=>$kanal,
					        'text'=>"💡 Diqqat yangi pro bot yaratildi 💡


💡 Bot turi: Pro				

🤖 Bot nomi $nomi  

🤖 Useri $user 

🗄 Id raqami $idsi 

🧑‍💻Yaratuvchi $nameuz 

⏳ ".date("Y-m-d H:i:s"),
					        'parse_mode'=>"html",
				        ]);	


				        putpro();					
  					} else {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);

				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'text'=>"📛 Noma'lum xatolik",
					        'parse_mode'=>"html"
				        ]);
          			}


				} else {
					bot('sendmessage', [
						'text'=>"📛 Menimcha siz tokenni yuborishda xatolikka yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!", 
						'chat_id'=>$cid, 
						'reply_markup'=>$mainBtn
					]);

				}

				step($fid, '');
			}


			if($data == 'sombot'){
			$get = file_get_contents("coin/$ccid/index.txt");
			if($get < $pro_narx ){
				    bot('editMessageText',[
				    'message_id'=>$cmid,
				    'chat_id'=>$ccid,
				    'text'=>"SO`M bot yaratish uchun $pro_narx ta ☣️ coin kerak. Quyidagi havolani do'stlaringizga tarqatib pul yig'ing:\n<code>https://t.me/$botname?start=$ccid </code>\n\nEslatib o'tamiz har bir do'stingiz sizga <b>$maincoin</b>ta coin beradi\n\nYoki @fayzlidev ga murojaat qilib coin sotib oling!",
				    'parse_mode'=>"html",
				    'disable_web_page_preview'=>true,
				    'reply_markup'=>json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"back"]],
					    ]
				    ])
			    ]);
			}else{
			bot('sendMessage',[
		    'chat_id'=>$ccid,
		    'text'=>"1️⃣ @BotFather-ga o'ting.  Botingiz tokenini jo‘nating

		💥Taxminiy API Token:
		 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
		    'reply_markup'=>json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"back"]],
					    ]
				    ])
		    ]);
		    step($ccid,"sombot&token");
		    }
		}


		if ( file_get_contents('./step/'.$fid.'.txt') == 'sombot&token' ) {
				$getMe = json_decode(get("https://api.telegram.org/bot$tx/getMe"));
				$nBot = 'sombot';
				if ($getMe->ok == 200) {
					bot('sendmessage', [
						'chat_id'=>$cid,
						'text'=>'Tayyorlanmoqda...'
					]);

				    $kod = file_get_contents("pro/$nBot.php");
				    $kod = str_replace("API_TOKEN", "$tx", $kod);
				    $kod = str_replace("ADMIN_ID", "$fid", $kod);
					$kod = str_replace("ADMIN_USER", "$user", $kod);
					mkdir("bots");
					mkdir("bots/$fid");
				    mkdir("bots/$fid/$nBot");
				    if(file_get_contents("bots/$fid/$nBot/$nBot.php")){
				        unlink("bots/$fid/$nBot/strtotime.php");
				        unlink("bots/$fid/$nBot/usid.txt");
				        unlink("bots/$fid/$nBot/grid.txt");
				        $files = glob("bots/$fid/$nBot/baza/*");
				        foreach ($files as $key) {
				        	unlink($key);
				        }
				        rmdir("bots/$fid/$nBot/baza");
				    }
    				file_put_contents("bots/$fid/$nBot/$nBot.php", $kod);
  					$get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/PHP/fayozbek/bots/$fid/$nBot/$nBot.php"))->result;


					$user = $getMe->result->username;
					$nomi = $getMe->result->first_name;
					$idsi = $getMe->result->id;


  					if ($get) {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);


				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'message_id'=>$getid,
					        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: PRO\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $idsi\n\n/panel - admin panel",
					        'parse_mode'=>"html",
					        'reply_markup'=>$mainBtn
				        ]);			


				        bot('sendMessage',[
					        'chat_id'=>$kanal,
					        'text'=>"💡 Diqqat yangi pro bot yaratildi 💡


💡 Bot turi: Pro				

🤖 Bot nomi $nomi  

🤖 Useri $user 

🗄 Id raqami $idsi 

🧑‍💻Yaratuvchi $nameuz 

⏳ ".date("Y-m-d H:i:s"),
					        'parse_mode'=>"html",
				        ]);	


				        putpro();			
  					} else {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);

				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'text'=>"📛 Noma'lum xatolik",
					        'parse_mode'=>"html"
				        ]);
          			}


				} else {
					bot('sendmessage', [
						'text'=>"📛 Menimcha siz tokenni yuborishda xatolikka yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!", 
						'chat_id'=>$cid, 
						'reply_markup'=>$mainBtn
					]);

				}

				step($fid, '');
			}


			if($data == 'ucbot'){
			$get = file_get_contents("coin/$ccid/index.txt");
			if($get < $pro_narx ){
				    bot('editMessageText',[
				    'message_id'=>$cmid,
				    'chat_id'=>$ccid,
				    'text'=>"UC bot yaratish uchun $pro_narx ta ☣️ coin kerak. Quyidagi havolani do'stlaringizga tarqatib pul yig'ing:\n<code>https://t.me/$botname?start=$ccid </code>\n\nEslatib o'tamiz har bir do'stingiz sizga <b>$maincoin</b>ta coin beradi\n\nYoki @fayzlidev ga murojaat qilib coin sotib oling!",
				    'parse_mode'=>"html",
				    'disable_web_page_preview'=>true,
				    'reply_markup'=>json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"back"]],
					    ]
				    ])
			    ]);
			}else{
			bot('sendMessage',[
		    'chat_id'=>$ccid,
		    'text'=>"1️⃣ @BotFather-ga o'ting.  Botingiz tokenini jo‘nating

		💥Taxminiy API Token:
		 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
		    'reply_markup'=>json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"back"]],
					    ]
				    ])
		    ]);
		    step($ccid,"ucbot&token");
		    }
		}


		if ( file_get_contents('./step/'.$fid.'.txt') == 'ucbot&token' ) {
				$getMe = json_decode(get("https://api.telegram.org/bot$tx/getMe"));
				$nBot = 'ucbot';
				if ($getMe->ok == 200) {
					bot('sendmessage', [
						'chat_id'=>$cid,
						'text'=>'Tayyorlanmoqda...'
					]);

				    $kod = file_get_contents("pro/$nBot.php");
				    $kod = str_replace("API_TOKEN", "$tx", $kod);
				    $kod = str_replace("ADMIN_ID", "$fid", $kod);
					$kod = str_replace("ADMIN_USER", "$user", $kod);
					mkdir("bots");
					mkdir("bots/$fid");
				    mkdir("bots/$fid/$nBot");
				    if(file_get_contents("bots/$fid/$nBot/$nBot.php")){
				        unlink("bots/$fid/$nBot/strtotime.php");
				        unlink("bots/$fid/$nBot/usid.txt");
				        unlink("bots/$fid/$nBot/grid.txt");
				        $files = glob("bots/$fid/$nBot/baza/*");
				        foreach ($files as $key) {
				        	unlink($key);
				        }
				        rmdir("bots/$fid/$nBot/baza");
				    }
    				file_put_contents("bots/$fid/$nBot/$nBot.php", $kod);
  					$get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/PHP/fayozbek/bots/$fid/$nBot/$nBot.php"))->result;


					$user = $getMe->result->username;
					$nomi = $getMe->result->first_name;
					$idsi = $getMe->result->id;


  					if ($get) {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);


				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'message_id'=>$getid,
					        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: PRO\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $idsi\n\n/panel - admin panel",
					        'parse_mode'=>"html",
					        'reply_markup'=>$mainBtn
				        ]);		


				        bot('sendMessage',[
					        'chat_id'=>$kanal,
					        'text'=>"💡 Diqqat yangi pro bot yaratildi 💡


💡 Bot turi: Pro				

🤖 Bot nomi $nomi  

🤖 Useri $user 

🗄 Id raqami $idsi 

🧑‍💻Yaratuvchi $nameuz 

⏳ ".date("Y-m-d H:i:s"),
					        'parse_mode'=>"html",
				        ]);	


				        putpro();				
  					} else {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);

				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'text'=>"📛 Noma'lum xatolik",
					        'parse_mode'=>"html"
				        ]);
          			}


				} else {
					bot('sendmessage', [
						'text'=>"📛 Menimcha siz tokenni yuborishda xatolikka yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!", 
						'chat_id'=>$cid, 
						'reply_markup'=>$mainBtn
					]);

				}

				step($fid, '');
			}


			if($data == 'usabot'){
			$get = file_get_contents("coin/$ccid/index.txt");
			if($get < $pro_narx ){
				    bot('editMessageText',[
				    'message_id'=>$cmid,
				    'chat_id'=>$ccid,
				    'text'=>"USA bot yaratish uchun $pro_narx ta ☣️ coin kerak. Quyidagi havolani do'stlaringizga tarqatib pul yig'ing:\n<code>https://t.me/$botname?start=$ccid </code>\n\nEslatib o'tamiz har bir do'stingiz sizga <b>$maincoin</b>ta coin beradi\n\nYoki @fayzlidev ga murojaat qilib coin sotib oling!",
				    'parse_mode'=>"html",
				    'disable_web_page_preview'=>true,
				    'reply_markup'=>json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"back"]],
					    ]
				    ])
			    ]);
			}else{
			bot('sendMessage',[
		    'chat_id'=>$ccid,
		    'text'=>"1️⃣ @BotFather-ga o'ting.  Botingiz tokenini jo‘nating

		💥Taxminiy API Token:
		 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
		    'reply_markup'=>json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"back"]],
					    ]
				    ])
		    ]);
		    step($ccid,"usabot&token");
		    }
		}


		if ( file_get_contents('./step/'.$fid.'.txt') == 'usabot&token' ) {
				$getMe = json_decode(get("https://api.telegram.org/bot$tx/getMe"));
				$nBot = 'usabot';
				if ($getMe->ok == 200) {
					bot('sendmessage', [
						'chat_id'=>$cid,
						'text'=>'Tayyorlanmoqda...'
					]);

				    $kod = file_get_contents("pro/$nBot.php");
				    $kod = str_replace("API_TOKEN", "$tx", $kod);
				    $kod = str_replace("ADMIN_ID", "$fid", $kod);
					$kod = str_replace("ADMIN_USER", "$user", $kod);
					mkdir("bots");
					mkdir("bots/$fid");
				    mkdir("bots/$fid/$nBot");
				    if(file_get_contents("bots/$fid/$nBot/$nBot.php")){
				        unlink("bots/$fid/$nBot/strtotime.php");
				        unlink("bots/$fid/$nBot/usid.txt");
				        unlink("bots/$fid/$nBot/grid.txt");
				        $files = glob("bots/$fid/$nBot/baza/*");
				        foreach ($files as $key) {
				        	unlink($key);
				        }
				        rmdir("bots/$fid/$nBot/baza");
				    }
    				file_put_contents("bots/$fid/$nBot/$nBot.php", $kod);
  					$get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/PHP/fayozbek/bots/$fid/$nBot/$nBot.php"))->result;


					$user = $getMe->result->username;
					$nomi = $getMe->result->first_name;
					$idsi = $getMe->result->id;


  					if ($get) {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);


				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'message_id'=>$getid,
					        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: PRO\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $idsi\n\n/panel - admin panel",
					        'parse_mode'=>"html",
					        'reply_markup'=>$mainBtn
				        ]);			


				        bot('sendMessage',[
					        'chat_id'=>$kanal,
					        'text'=>"💡 Diqqat yangi pro bot yaratildi 💡


💡 Bot turi: Pro				

🤖 Bot nomi $nomi  

🤖 Useri $user 

🗄 Id raqami $idsi 

🧑‍💻Yaratuvchi $nameuz 

⏳ ".date("Y-m-d H:i:s"),
					        'parse_mode'=>"html",
				        ]);	


				        putpro();			
  					} else {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);

				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'text'=>"📛 Noma'lum xatolik",
					        'parse_mode'=>"html"
				        ]);
          			}


				} else {
					bot('sendmessage', [
						'text'=>"📛 Menimcha siz tokenni yuborishda xatolikka yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!", 
						'chat_id'=>$cid, 
						'reply_markup'=>$mainBtn
					]);

				}

				step($fid, '');
			}


			if($data == 'bcbot'){
			$get = file_get_contents("coin/$ccid/index.txt");
			if($get < $pro_narx ){
				    bot('editMessageText',[
				    'message_id'=>$cmid,
				    'chat_id'=>$ccid,
				    'text'=>"📦BC bot yaratish uchun $pro_narx ta ☣️ coin kerak. Quyidagi havolani do'stlaringizga tarqatib pul yig'ing:\n<code>https://t.me/$botname?start=$ccid </code>\n\nEslatib o'tamiz har bir do'stingiz sizga <b>$maincoin</b>ta coin beradi\n\nYoki @fayzlidev ga murojaat qilib coin sotib oling!",
				    'parse_mode'=>"html",
				    'disable_web_page_preview'=>true,
				    'reply_markup'=>json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"back"]],
					    ]
				    ])
			    ]);
			}else{
			bot('sendMessage',[
		    'chat_id'=>$ccid,
		    'text'=>"1️⃣ @BotFather-ga o'ting.  Botingiz tokenini jo‘nating

		💥Taxminiy API Token:
		 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
		    'reply_markup'=>json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"back"]],
					    ]
				    ])
		    ]);
		    step($ccid,"bcbot&token");
		    }
		}


		if ( file_get_contents('./step/'.$fid.'.txt') == 'bcbot&token' ) {
				$getMe = json_decode(get("https://api.telegram.org/bot$tx/getMe"));
				$nBot = 'bcbot';
				if ($getMe->ok == 200) {
					bot('sendmessage', [
						'chat_id'=>$cid,
						'text'=>'Tayyorlanmoqda...'
					]);

				    $kod = file_get_contents("pro/$nBot.php");
				    $kod = str_replace("API_TOKEN", "$tx", $kod);
				    $kod = str_replace("ADMIN_ID", "$fid", $kod);
					$kod = str_replace("ADMIN_USER", "$user", $kod);
					mkdir("bots");
					mkdir("bots/$fid");
				    mkdir("bots/$fid/$nBot");
				    if(file_get_contents("bots/$fid/$nBot/$nBot.php")){
				        unlink("bots/$fid/$nBot/strtotime.php");
				        unlink("bots/$fid/$nBot/usid.txt");
				        unlink("bots/$fid/$nBot/grid.txt");
				        $files = glob("bots/$fid/$nBot/baza/*");
				        foreach ($files as $key) {
				        	unlink($key);
				        }
				        rmdir("bots/$fid/$nBot/baza");
				    }
    				file_put_contents("bots/$fid/$nBot/$nBot.php", $kod);
  					$get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/PHP/fayozbek/bots/$fid/$nBot/$nBot.php"))->result;


					$user = $getMe->result->username;
					$nomi = $getMe->result->first_name;
					$idsi = $getMe->result->id;


  					if ($get) {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);


				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'message_id'=>$getid,
					        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: PRO\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $idsi\n\n/panel - admin panel",
					        'parse_mode'=>"html",
					        'reply_markup'=>$mainBtn
				        ]);		


				        bot('sendMessage',[
					        'chat_id'=>$kanal,
					        'text'=>"💡 Diqqat yangi pro bot yaratildi 💡


💡 Bot turi: Pro				

🤖 Bot nomi $nomi  

🤖 Useri $user 

🗄 Id raqami $idsi 

🧑‍💻Yaratuvchi $nameuz 

⏳ ".date("Y-m-d H:i:s"),
					        'parse_mode'=>"html",
				        ]);	


				        putpro();				
  					} else {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);

				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'text'=>"📛 Noma'lum xatolik",
					        'parse_mode'=>"html"
				        ]);
          			}


				} else {
					bot('sendmessage', [
						'text'=>"📛 Menimcha siz tokenni yuborishda xatolikka yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!", 
						'chat_id'=>$cid, 
						'reply_markup'=>$mainBtn
					]);

				}

				step($fid, '');
			}


			if($data == 'mbbot'){
			$get = file_get_contents("coin/$ccid/index.txt");
			if($get < $pro_narx ){
				    bot('editMessageText',[
				    'message_id'=>$cmid,
				    'chat_id'=>$ccid,
				    'text'=>"Mb Bot bot yaratish uchun $pro_narx ta ☣️ coin kerak. Quyidagi havolani do'stlaringizga tarqatib pul yig'ing:\n<code>https://t.me/$botname?start=$ccid </code>\n\nEslatib o'tamiz har bir do'stingiz sizga <b>$maincoin</b>ta coin beradi\n\nYoki @fayzlidev ga murojaat qilib coin sotib oling!",
				    'parse_mode'=>"html",
				    'disable_web_page_preview'=>true,
				    'reply_markup'=>json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"back"]],
					    ]
				    ])
			    ]);
			}else{
			bot('sendMessage',[
		    'chat_id'=>$ccid,
		    'text'=>"1️⃣ @BotFather-ga o'ting.  Botingiz tokenini jo‘nating

		💥Taxminiy API Token:
		 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
		    'reply_markup'=>json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"back"]],
					    ]
				    ])
		    ]);
		    step($ccid,"mbbot&token");
		    }
		}


		if ( file_get_contents('./step/'.$fid.'.txt') == 'mbbot&token' ) {
				$getMe = json_decode(get("https://api.telegram.org/bot$tx/getMe"));
				$nBot = 'mbbot';
				if ($getMe->ok == 200) {
					bot('sendmessage', [
						'chat_id'=>$cid,
						'text'=>'Tayyorlanmoqda...'
					]);

				    $kod = file_get_contents("pro/$nBot.php");
				    $kod = str_replace("API_TOKEN", "$tx", $kod);
				    $kod = str_replace("ADMIN_ID", "$fid", $kod);
					$kod = str_replace("ADMIN_USER", "$user", $kod);
					mkdir("bots");
					mkdir("bots/$fid");
				    mkdir("bots/$fid/$nBot");
				    if(file_get_contents("bots/$fid/$nBot/$nBot.php")){
				        unlink("bots/$fid/$nBot/strtotime.php");
				        unlink("bots/$fid/$nBot/usid.txt");
				        unlink("bots/$fid/$nBot/grid.txt");
				        $files = glob("bots/$fid/$nBot/baza/*");
				        foreach ($files as $key) {
				        	unlink($key);
				        }
				        rmdir("bots/$fid/$nBot/baza");
				    }
    				file_put_contents("bots/$fid/$nBot/$nBot.php", $kod);
  					$get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/PHP/fayozbek/bots/$fid/$nBot/$nBot.php"))->result;


					$user = $getMe->result->username;
					$nomi = $getMe->result->first_name;
					$idsi = $getMe->result->id;


  					if ($get) {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);


				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'message_id'=>$getid,
					        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: PRO\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $idsi\n\n/panel - admin panel",
					        'parse_mode'=>"html",
					        'reply_markup'=>$mainBtn
				        ]);		


				        bot('sendMessage',[
					        'chat_id'=>$kanal,
					        'text'=>"💡 Diqqat yangi pro bot yaratildi 💡


💡 Bot turi: Pro				

🤖 Bot nomi $nomi  

🤖 Useri $user 

🗄 Id raqami $idsi 

🧑‍💻Yaratuvchi $nameuz 

⏳ ".date("Y-m-d H:i:s"),
					        'parse_mode'=>"html",
				        ]);	


				        putpro();				
  					} else {
        				bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid + 1]);

				        bot('sendMessage',[
					        'chat_id'=>$cid,
					        'text'=>"📛 Noma'lum xatolik",
					        'parse_mode'=>"html"
				        ]);
          			}


				} else {
					bot('sendmessage', [
						'text'=>"📛 Menimcha siz tokenni yuborishda xatolikka yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!", 
						'chat_id'=>$cid, 
						'reply_markup'=>$mainBtn
					]);

				}

				step($fid, '');
			}




			// PROOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

		}
	} 

		$backadmin = json_encode([
					    'inline_keyboard'=>[
						    [['text'=>"◀️Orqaga",'callback_data'=>"backadmin"]],
					    ]
				    ]);


		$adminBtn = json_encode([
			    'inline_keyboard'=>[
				    [['text'=>"☣️ Coin sozlash",'callback_data'=>"setcoin"]],
				    [['text'=>"💴 Money narxini sozlash",'callback_data'=>"setmoney"]],
				    [['text'=>"🛡  Pro narxini sozlash",'callback_data'=>"setpro"]],
				    [['text'=>"🟡 ➕",'callback_data'=>"addcoin"], ['text'=>"🟡 ➖",'callback_data'=>"deletecoin"]],
				    [['text'=>"✉️ Xabar yuborish (👤 userga 👤)",'callback_data'=>"sendtouser"], ['text'=>"✉️ Xabar yuborish (👥 userga 👥)",'callback_data'=>"sendtousers"]],
				    [['text'=>"🔰Bot listini tozalash",'callback_data'=>"listcode"]],
				    [['text'=>"◀️Orqaga",'callback_data'=>"menu"]],
			    ]
		    ]);

	if ( ($text == '/admin' and $cid == $admin) ) {



		bot('sendmessage', [
			'chat_id'=>$cid,
			'text'=>"🖐Salom. \n\n👨‍💻Admin Panelga kirdingiz.",
			'reply_markup'=>$adminBtn
		]);


		file_put_contents('admin.step', '');

	} else if($text == '/admin' and $cid !== $admin) {
		bot('sendmessage', [
			'chat_id'=>$cid,
			'text'=>"Siz admin emassiz !!!",
			'reply_markup'=>$mainBtn
		]);



		bot('sendmessage', [
			'chat_id'=>$admin,
			'text'=>"Ogohlantirish!!! \n\n\nAdmin👨‍💻 panelga kirmoqchi bo`lishdi\n\nID: $cid \n\nIsmi: $name \n\nProfil: <a href='tg://user?id=$cid'> USER </a>",
			'parse_mode'=>'html'
		]);
	}

	if ($data == 'backadmin' and $ccid==$admin) {
		


		bot('editMessageText', [
			'chat_id'=>$ccid,
			'message_id'=>$cmid,
			'text'=>"👨‍💻Admin Panel",
			'reply_markup'=>$adminBtn
		]);


		file_put_contents('admin.step', '');
	}


	if ($data == 'setcoin' and $ccid == $admin) {
		bot('editMessageText', [
			'message_id'=>$cmid,
			'chat_id'=>$ccid,
			'text'=>"☣️ Hozirda 1ta referalga beriladigan coin: $maincoin \n\n👥 1ta 👥 referalga beriladigan coin ni kiriting: ",
			'reply_markup'=>$backadmin
		]);

		file_put_contents('admin.step', 'setcoin');
	}

	if ($cid == $admin and file_get_contents('admin.step') == 'setcoin') {
		$tx = intval($tx);
		bot('sendmessage', [
			'chat_id'=>$cid,
			'text'=>"✅ Omadli ✅\n\n👥 1ta 👥 referalga beriladigan ☣️ coin ☣️: $tx ",
			'reply_markup'=>$adminBtn
		]);
		file_put_contents('narxlar/maincoin.txt', $tx);

		file_put_contents('admin.step', '');
	}



	if ($data == 'setmoney' and $ccid == $admin) {
		bot('editMessageText', [
			'message_id'=>$cmid,
			'chat_id'=>$ccid,
			'text'=>"💰 Hozirda Pul bot oladigan coin: $pullik_narx\n\n💰 Pul bot oladigan coin ni kiriting: ",
			'reply_markup'=>$backadmin
		]);

		file_put_contents('admin.step', 'setmoney');
	}

	if ($cid == $admin and file_get_contents('admin.step') == 'setmoney') {
		$tx = intval($tx);
		bot('sendmessage', [
			'chat_id'=>$cid,
			'text'=>"✅ Omadli ✅\n\n💰Pul bot oladigan coin: $tx ",
			'reply_markup'=>$adminBtn
		]);
		file_put_contents('narxlar/pullik_narx.txt', $text);
		file_put_contents('admin.step', '');
	}



	if ($data == 'setpro' and $ccid == $admin) {
		bot('editMessageText', [
			'message_id'=>$cmid,
			'chat_id'=>$ccid,
			'text'=>"🛡 Hozirda Pro bot oladigan coin: $pro_narx \n\n🛡 Pro bot oladigan coin ni kiriting: ",
			'reply_markup'=>$backadmin
		]);

		file_put_contents('admin.step', 'setpro');
	}

	if ($cid == $admin and file_get_contents('admin.step') == 'setpro') {
		$tx = intval($tx);
		bot('sendmessage', [
			'message_id'=>$mid,
			'chat_id'=>$cid,
			'text'=>"✅ Omadli ✅\n\n🛡 Pro bot oladigan coin: $tx ",
			'reply_markup'=>$adminBtn
		]);
		file_put_contents('narxlar/pro_narx.txt', $tx);
		file_put_contents('admin.step', '');
	}


	if ($data == 'addcoin' and $ccid == $admin) {
		bot('editMessageText', [
			'message_id'=>$cmid,
			'chat_id'=>$ccid,
			'text'=>"Coin bermoqchi bo`lgan user idsi va coin miqdorini kiriting!

🧩Namuna: $ccid 1000
			",
			'reply_markup'=>$backadmin
		]);



		file_put_contents('admin.step', 'addcoin');

	}




	if ($cid == $admin and file_get_contents('admin.step') == 'addcoin') {
		$cc = explode(' ', $tx);
		bot('sendmessage', [
			'chat_id'=>$cid,
			'text'=>"✅ Omadli ✅\n\n <a href='tg://user?id=$cc[0]'> Ushbu </a> userga $cc[1]ta coin berildi. ",
			'parse_mode'=>'html',
			'reply_markup'=>$adminBtn
		]);


		bot('sendmessage', [
			'chat_id'=>$cc[0],
			'text'=>"✅ Sizga admin tomonidan $cc[1]ta coin berildi. ✅",
		]);
		$coinadd = file_get_contents('coin/'.$cc[0].'/index.txt') ? file_get_contents('coin/'.$cc[0].'/index.txt') : 0;
		$coinadd = intval($coinadd);
		$coinadd = $coinadd + $cc[1];
		file_put_contents('coin/'.$cc[0].'/index.txt', $coinadd);
		file_put_contents('admin.step', '');
	}




	if ($data == 'deletecoin' and $ccid == $admin) {
		bot('editMessageText', [
			'message_id'=>$cmid,
			'chat_id'=>$ccid,
			'text'=>"Coin olmoqchi bo`lgan user idsi va coin miqdorini kiriting!

🧩Namuna: $ccid 1000
			",
			'reply_markup'=>$backadmin
		]);



		file_put_contents('admin.step', 'deletecoin');

	}




	if ($cid == $admin and file_get_contents('admin.step') == 'deletecoin') {
		$cc = explode(' ', $tx);
		bot('sendmessage', [
			'chat_id'=>$cid,
			'text'=>"✅ Omadli ✅\n\n <a href='tg://user?id=$cc[0]'> Ushbu </a> userdan $cc[1]ta coin olib tashlandi. ",
			'parse_mode'=>'html',
			'reply_markup'=>$adminBtn
		]);


		bot('sendmessage', [
			'chat_id'=>$cc[0],
			'text'=>"✅ Sizdan admin tomonidan $cc[1]ta coin olib tashlandi. ",
		]);

		$coinadd = file_get_contents('coin/'.$cc[0].'/index.txt') ? file_get_contents('coin/'.$cc[0].'/index.txt') : 0;
		$coinadd = intval($coinadd);
		$coinadd = $coinadd - $cc[1];
		file_put_contents('coin/'.$cc[0].'/index.txt', $coinadd);
		file_put_contents('admin.step', '');

	}



	if ($data == 'sendtouser' and $ccid == $admin) {
		bot('editMessageText', [
			'message_id'=>$cmid,
			'chat_id'=>$ccid,
			'text'=>"Xabar yubormoqchi bo`lgan user idsi va userga yubormoqchi bolgan textni kiriting!

🧩Namuna: $ccid Text
			",
			'reply_markup'=>$backadmin
		]);



		file_put_contents('admin.step', 'sendtouser');

	}




	if ($cid == $admin and file_get_contents('admin.step') == 'sendtouser') {
		$cc = explode(' ', $tx);
		bot('sendmessage', [
			'chat_id'=>$cid,
			'text'=>"✅ Omadli ✅\n\n <a href='tg://user?id=$cc[0]'> Ushbu </a> userga xabar yuborildi. Xabar: $cc[1] ",
			'parse_mode'=>'html',
			'reply_markup'=>$adminBtn
		]);


		bot('sendmessage', [
			'chat_id'=>$cc[0],
			'text'=>"✅ Admindan xabar ✅\n\nXabar: $cc[1]",
		]);
		file_put_contents('admin.step', '');
	}



	if ($text == '/clearbots') {
		bot('sendmessage', ['chat_id'=>$cid,'text'=>'✅ Bot listi tozalandi. 🔰']);
		file_put_contents('statistika/freebots.txt', '');

		file_put_contents('statistika/moneybots.txt', '');
		file_put_contents('statistika/probots.txt', '');
	}


	if ($data == 'listcode' and $ccid == $admin) {
		bot('sendmessage', ['chat_id'=>$ccid,'text'=>'✅ Bot listini tozalash uchun  /clearbots buyrug`ini yuboring. ']);
	}






	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  
	// WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK WEBHOOK  


	$webhookBtn = json_encode([
	'inline_keyboard'=>[
		[['text'=>"🪛 Webhook sozlash",'callback_data'=>"setwebhook"],],
		[['text'=>"❇ ️Token haqida ma'lumot",'callback_data'=>"getwebhook"],],
		[['text'=>"❌ Webhook o'chirish",'callback_data'=>"deletewebhook"],],
		[['text'=>"◀️Ortga",'callback_data'=>"menu"],],
	]
]);
	if($tx == '♻️ Webhook') {
		bot('sendMessage', [
			'chat_id'=>$cid,
			'text'=>"🔰 <b> Webhook bo'limi </b> 🔰 ",
			'parse_mode'=>'html',
			'reply_markup'=>$webhookBtn
		]);
		file_put_contents('./user/'.$fid.'/step.txt', 'webhook');
		step($fid, '');
	} elseif ($data == 'setwebhook') {
		bot('editMessageText', [
			'chat_id'=>$ccid,
			'message_id'=>$cmid,
			'text'=>"🔰<b>@BotFather dan olgan tokeningizni yuboring \n\n🧩Namuna:  1234567890:AAH7glkRIRE0U_DUhwGu6F3Ypv_zRGo9RRE </b>  ",
			'parse_mode'=>'html',
			'reply_markup'=>json_encode([
								'inline_keyboard'=>[
									[['text'=>"◀️Ortga",'callback_data'=>"towebhook"],],
								]
							])
		]);


		step($ccid, 'setwebhook1');
	}  elseif ($tx!==null and $getstep == 'setwebhook1' and $data !== 'menu' ) {
		$gethook = json_decode(file_get_contents('https://api.telegram.org/bot'.$tx."/getMe"));
		if (!$gethook->ok) {
			bot('sendMessage', [
				'chat_id'=>$cid,
				'text'=>"🚫 <b> Tokeningiz xato! </b> 🚫 ",
				'parse_mode'=>'html',
				'reply_markup'=>$webhookBtn
			]);

			step($fid, '');
			exit();
		}

		bot('sendmessage', [
			'chat_id'=>$cid,
			'text'=>" <b> ✅Omadli✅  \n\nEndi esa serveringizdagi bot fayli manzilini kiriting\n\n🧩Namuna: https://saytnomi.com/faylnomi.php   </b> ",
			'parse_mode'=>'html',
			'reply_markup'=>json_encode([
								'inline_keyboard'=>[
									[['text'=>"◀️Ortga",'callback_data'=>"towebhook"],],
								]
							])
		]);

		put('webhook/'.$fid."/token.txt", $tx);
		step($fid, 'setwebhook2');
	} elseif ($tx!==null and $getstep == 'setwebhook2' and $data !== 'menu' ) {
		if (mb_stripos($tx, 'https://')) {
			bot('sendMessage', [
				'chat_id'=>$cid,
				'text'=>"🚫<b>Fayl mazili xato kiritilgan! </b> 🚫 ",
				'parse_mode'=>'html',
				'reply_markup'=>$webhookBtn
			]);

			step($fid, '');
			put('webhook/'.$fid."/token.txt", '');
			exit();
		}
		$gettoken = get('webhook/'.$fid."/token.txt");
		bot('sendmessage', [
			'chat_id'=>$cid,
			'text'=>"<b>✅Omadli✅     


🔍 Kiritgan ma’lumotlaringizni tekshirib oling:
    
•🤖 Tokeningiz • $gettoken
    
•📍 Sayt manzili • $tx
    
•🔰 To'g'ri kiritgan bo'lsangiz:
/setwebhook 👈 bosing
</b> ",
			'parse_mode'=>'html',
			'reply_markup'=>json_encode([
								'inline_keyboard'=>[
									[['text'=>"◀️Ortga",'callback_data'=>"towebhook"],],
								]
							])
		]);

		put('webhook/'.$fid."/url.txt", $tx);
		step($fid, 'setwebhook3');
	} elseif ($data == 'towebhook') {
		bot('editMessageText', [
			'chat_id'=>$ccid,
			'message_id'=>$cmid,
			'text'=>"🔰 <b> Webhook bo'limi </b> 🔰 ",
			'parse_mode'=>'html',
			'reply_markup'=>$webhookBtn
		]);

		step($ccid, '');
	} elseif ($tx=='/setwebhook' and $getstep=='setwebhook3') {
		$gettoken = get('webhook/'.$fid."/token.txt");
		$geturl = get('webhook/'.$fid."/url.txt");
                $fulurl = "https://api.telegram.org/bot".$gettoken."/setwebhook?url=".$geturl;
		$getupdate = file_get_contents($fulurl);
file_put_contents('tt.txt',$getupdate);


		if ($getupdate) {
			bot('sendmessage', [
				'chat_id'=>$cid,
				'text'=>"<b>✅Webhook sozlandi!✅</b> ",
				'parse_mode'=>'html',
				'reply_markup'=>$webhookBtn
			]);
		}


		else {
			bot('sendmessage', [
				'chat_id'=>$cid,
				'text'=>"🚫<b>Xatolik yuzaga keldi. Iltimos birozdan so'ng urunib ko'ring</b>🚫 ",
				'parse_mode'=>'html',
				'reply_markup'=>$webhookBtn
			]);
		}



		step($fid, '');

	} elseif ($data == 'getwebhook') {
			bot('editMessageText', [
				'chat_id'=>$ccid,
				'message_id'=>$cmid,
				'text'=>"<b>📎 Botingizni tokenini yuboring!</b>  ",
				'parse_mode'=>'html',
				'reply_markup'=>json_encode([
								'inline_keyboard'=>[
									[['text'=>"◀️Ortga",'callback_data'=>"towebhook"],],
								]
							])
			]);

		step($ccid, 'getwebhook1');
	} elseif($getstep == 'getwebhook1' and $tx!==null and $data !== 'towebhook') {
		$getupdate = json_decode(get('https://api.telegram.org/bot'.$tx.'/getMe'));

		if ($getupdate) {
			$botname = $getupdate->result->first_name;
			$botuser = $getupdate->result->username;
			$botid = $getupdate->result->id;
			$boturl = json_decode(get('https://api.telegram.org/bot'.$tx.'getwebhookinfo'))->result->url;
			bot('sendmessage', [
				'chat_id'=>$cid,
				'text'=>"<b>🔰 Malumotlar mavjud! 🔰
➖➖➖➖➖
❇️ Bot Nomi :  $botname
🪛 Bot Useri : @$botuser
🆔 Bot IDsi : $botid
💡 Fayl manzili : ⤵
$boturl</b> ",
				'parse_mode'=>'html',
				'reply_markup'=>$webhookBtn
			]);
		} else {
			bot('sendmessage', [
				'chat_id'=>$cid,
				'text'=>"🚫<b>Tokeningiz xato! Iltimos botingizni tokeni to'g'riligiga ishonch hosil qilib keyin urinib ko'ring</b>🚫 ",
				'parse_mode'=>'html',
				'reply_markup'=>$webhookBtn
			]);
		}
	}  elseif ($data == 'deletewebhook') {
			bot('editMessageText', [
				'chat_id'=>$ccid,
				'message_id'=>$cmid,
				'text'=>"<b>📎 Botingizni tokenini yuboring!</b>  ",
				'parse_mode'=>'html',
				'reply_markup'=>json_encode([
								'inline_keyboard'=>[
									[['text'=>"◀️Ortga",'callback_data'=>"towebhook"],],
								]
							])
			]);

		step($ccid, 'deletewebhook1');
	} elseif($getstep == 'deletewebhook1' and $tx!==null and $data !== 'towebhook') {
		$getupdate = json_decode(get('https://api.telegram.org/bot'.$tx.'/getMe'));

		if ($getupdate) {
			$getupdate = json_decode(get('https://api.telegram.org/bot'.$tx.'/deletewebhook'));
			if (!$getupdate) {
				bot('sendmessage', [
					'chat_id'=>$cid,
					'text'=>"<b>🚫 Serverda xato! Webhook o'chirilmadi 🚫</b> ",
					'parse_mode'=>'html',
					'reply_markup'=>$webhookBtn
				]);
				exit();
			}

			bot('sendmessage', [
				'chat_id'=>$cid,
				'text'=>"<b>⚡️ Webhook muvaffaqiyatli o'chirildi!</b> ",
				'parse_mode'=>'html',
				'reply_markup'=>$webhookBtn
			]);
		} else {
			bot('sendmessage', [
				'chat_id'=>$cid,
				'text'=>"🚫<b>Tokeningiz xato! Iltimos botingizni tokeni to'g'riligiga ishonch hosil qilib keyin urinib ko'ring</b>🚫 ",
				'parse_mode'=>'html',
				'reply_markup'=>$webhookBtn
			]);
		}
	}

	// OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO
	// OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO
	// OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO
	// OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO
	// OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO
	// OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO
	// OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO
	// OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO
	// OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO
	// OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO
	// OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO
	// OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO
	// OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO
	// OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO
	// OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO OBHAVO
	if ($text == '🌄 Ob havo' and $getstep == '') {
		file_put_contents('./user/'.$fid.'/step.txt', 'obhavo');
		bot('sendmessage', [
			'chat_id'=>$cid,
			'text'=>"<b>🌦 Qaysi shaxarni ob havosini bilmoqchisiz ?\n\n🧩Namuna: Tashkent</b>",
			'parse_mode'=>'html',
			'reply_markup'=>json_encode([
				'inline_keyboard'=>[
					[['text'=>"◀️Ortga",'callback_data'=>"menu"],],
				]
			])
		]);
		step($fid, "weather1");
	} elseif($getstep == 'weather1' and $tx and $data !== 'menu') {
		$getweather = json_decode(file_get_contents("https://api.openweathermap.org/data/2.5/weather?appid=d2c61fd2d7ffc84b40cb328aa52cbcc8&q=$tx"));


		if ($getweather) {
			$photoid = $getweather->weather[0]->icon;
			$location = $getweather->sys->country;
			$temp = $getweather->main->temp - 273.15;
			$windspeed = $getweather->wind->speed;
			$weathername = $getweather->name;
			$photourl = "https://openweathermap.org/img/wn/$photoid@4x.png";
			bot('sendphoto', [
				'chat_id'=>$cid,
				'photo'=>$photourl,
				'caption'=>"<b>🌦 $weathername da bugungi ob-havo ma'lumotlari:  

 📍 Joylashuv: $location 
 🌡 Havo harorati: $temp °C 
 💨 Shamol Tezligi $windspeed m/s</b>",
				'parse_mode'=>'html',
				'reply_markup'=>$mainBtn
			]);
		} else {
			bot('sendmessage', [
				'chat_id'=>$cid,
				'text'=>"<b>🚫 Siz kiritgan shaxar nomi topilmadi. 🚫 \n\n\n🖥 Siz asosiy menyudasiz</b>",
				'parse_mode'=>'html',
				'reply_markup'=>$mainBtn
			]);
		}
		step($fid, "");
	}
}


